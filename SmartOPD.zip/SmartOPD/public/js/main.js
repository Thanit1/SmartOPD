const socket = io();

// เพิ่มตัวแปรสำหรับจัดการ Modal
let alertModal;
let reconnectModal;
let currentReconnectType = null;
let errorModal;

// เพิ่มตัวแปรสำหรับตรวจสอบการเชื่อมต่อ
let connectionCheckInterval;

// เพิ่มตัวแปรสำหรับเก็บสถานะก่อนหน้า
let previousStatus = {
    pressure: { connected: false },
    temp: { connected: false }
};

// สร้าง Modal instances เมื่อโหลดหน้า
document.addEventListener('DOMContentLoaded', () => {
    alertModal = new bootstrap.Modal(document.getElementById('alertModal'));
    reconnectModal = new bootstrap.Modal(document.getElementById('reconnectModal'));
    errorModal = new bootstrap.Modal(document.getElementById('errorModal'));
    
    // เริ่มการตรวจสอบการเชื่อมต่อทุก 2 วินาที
    startConnectionCheck();
});

// ฟังก์ชันเริ่มการตรวจสอบการเชื่อมต่อ
function startConnectionCheck() {
    // ยกเลิก interval เดิมถ้ามี
    if (connectionCheckInterval) {
        clearInterval(connectionCheckInterval);
    }
    
    // ตรวจสอบทุก 2 วินาที
    connectionCheckInterval = setInterval(() => {
        socket.emit('getConnectionStatus');
    }, 2000);
}

// อัพเดทสถานะการเชื่อมต่อ
socket.on('connectionStatus', (status) => {
    console.log('Connection status received:', status); // เพิ่ม log
    connectionStatus = status;
    
    // อัพเดทสถานะเริ่มต้น
    if (previousStatus.pressure.connected && !status.pressure?.connected) {
        showErrorModal('pressure');
    }
    if (previousStatus.temp.connected && !status.temp?.connected) {
        showErrorModal('temp');
    }
    
    updateConnectionStatus();
});

// เพิ่มการจัดการเมื่อการเชื่อมต่อหลุด
socket.on('disconnect', () => {
    console.log('Socket disconnected');
    // ทำให้สถานะทุกพอร์ตเป็น disconnected
    connectionStatus = {
        pressure: { connected: false },
        temp: { connected: false }
    };
    updateConnectionStatus();
});

// เพิ่มการจัดการเมื่อเชื่อมต่อกลับมา
socket.on('connect', () => {
    console.log('Socket connected');
    // ขอสถานะการเชื่อมต่อใหม่
    socket.emit('getConnectionStatus');
});

// อัพเดท updateConnectionStatus function
function updateConnectionStatus() {
    const pressureStatus = document.getElementById('pressureStatus');
    const tempStatus = document.getElementById('tempStatus');

    // ตรวจสอบการเปลี่ยนแปลงสถานะ pressure
    if (connectionStatus.pressure?.connected) {
        pressureStatus.textContent = 'เชื่อมต่อแล้ว';
        pressureStatus.className = 'badge bg-success';
        previousStatus.pressure.connected = true;
        if (document.querySelector('#errorModal.show')) {
            const currentErrorCode = document.getElementById('errorCode').textContent;
            if (currentErrorCode.includes('PRESSURE')) {
                const modalInstance = bootstrap.Modal.getInstance(document.getElementById('errorModal'));
                if (modalInstance) {
                    modalInstance.hide();
                }
            }
        }
    } else {
        pressureStatus.textContent = 'ไม่ได้เชื่อมต่อ';
        pressureStatus.className = 'badge bg-secondary';
        showErrorModal('pressure');
        previousStatus.pressure.connected = false;
    }

    // ตรวจสอบการเปลี่ยนแปลงสถานะ temp
    if (connectionStatus.temp?.connected) {
        tempStatus.textContent = 'เชื่อมต่อแล้ว';
        tempStatus.className = 'badge bg-success';
        previousStatus.temp.connected = true;
        if (document.querySelector('#errorModal.show')) {
            const currentErrorCode = document.getElementById('errorCode').textContent;
            if (currentErrorCode.includes('TEMP')) {
                const modalInstance = bootstrap.Modal.getInstance(document.getElementById('errorModal'));
                if (modalInstance) {
                    modalInstance.hide();
                }
            }
        }
    } else {
        tempStatus.textContent = 'ไม่ได้เชื่อมต่อ';
        tempStatus.className = 'badge bg-secondary';
        showErrorModal('temp');
        previousStatus.temp.connected = false;
    }
}

// เพิ่มตัวแปรสำหรับจัดการการเชื่อมต่อซ้ำ
let reconnectTimers = {
    pressure: null,
    temp: null
};

// ฟังก์ชันพยายามเชื่อมต่อใหม่
function attemptReconnect(type) {
    // อ่านค่า config และพยายามเชื่อมต่อใหม่
    socket.emit('getPortConfig');
}

// รับค่า port config และพยายามเชื่อมต่อ
socket.on('portConfig', (config) => {
    if (config.ports) {
        Object.entries(config.ports).forEach(([type, portConfig]) => {
            if (portConfig.enabled && !connectionStatus[type]?.connected) {
                socket.emit('togglePort', {
                    type: type,
                    port: portConfig.path,
                    action: 'connect'
                });
            }
        });
    }
});

// ยกเลิกการเชื่อมต่อซ้ำเมื่อเชื่อมต่อสำเร็จ
socket.on('portSuccess', (data) => {
    const { type } = data;
    // ปิด Modal ถ้าเชื่อมต่อสำเร็จ
    const modalElement = document.getElementById('errorModal');
    const modalInstance = bootstrap.Modal.getInstance(modalElement);
    if (modalInstance) {
        const currentErrorCode = document.getElementById('errorCode').textContent;
        if (currentErrorCode.includes(type.toUpperCase())) {
            modalInstance.hide();
        }
    }
    
    // รีเฟรชหน้าเว็บเมื่อเชื่อมต่อสำเร็จ
    window.location.reload();
});

// แสดงข้อความแจ้งเตือน
socket.on('portError', (data) => {
    console.log('Port error received:', data); // เพิ่ม log
    const { type, code, message } = data;
    showErrorModal(type);
});

// ฟังก์ชันแสดงการแจ้งเตือน
function showAlert(message, type) {
    const modalMessage = document.getElementById('modalMessage');
    modalMessage.textContent = message;
    
    const modalDialog = document.querySelector('#alertModal .modal-content');
    modalDialog.className = 'modal-content';
    modalDialog.classList.add(`border-${type}`);
    
    alertModal.show();
    
    // ปิด Modal อัตโนมัติหลังจาก 3 วินาที (สำหรับ success) หรือ 5 วินาที (สำหรับ warning)
    setTimeout(() => {
        alertModal.hide();
    }, type === 'success' ? 3000 : 5000);
}

// อัพเดทค่าที่วัดได้
socket.on('temperature', (temp) => {
    console.log('Received temperature:', temp); // เพิ่ม log
    if (temp !== undefined && temp !== null) {
        document.getElementById('temperature').textContent = temp;
    } else {
        document.getElementById('temperature').textContent = '-'; // Default or placeholder value
    }
});

socket.on('pressure', (data) => {
    console.log('Received pressure:', data); // เพิ่ม log
    if (data) {
        document.getElementById('systolic').textContent = data.systolic ?? '-';
        document.getElementById('diastolic').textContent = data.diastolic ?? '-';
        document.getElementById('pulse').textContent = data.pulse ?? '-';
    } else {
        document.getElementById('systolic').textContent = '-';
        document.getElementById('diastolic').textContent = '-';
        document.getElementById('pulse').textContent = '-';
    }
});


// ขอสถานะการเชื่อมต่อเมื่อโหลดหน้า
socket.emit('getConnectionStatus');
socket.emit('getPortConfig');
    
// เพิ่มฟังก์ชันแสดง error modal
function showErrorModal(type) {
    const deviceName = type === 'pressure' ? 'เครื่องวัดความดัน' : 'เครื่องวัดอุณหภูมิ';

    // Check if the device is really disconnected
    if (!connectionStatus[type]?.connected) {
        const errorCodeText = `ERR_${type.toUpperCase()}_DISCONNECTED`;
        const errorMessageText = `การเชื่อมต่อกับ${deviceName}ถูกตัดขาด กรุณาตรวจสอบการเชื่อมต่อและทำตามคำแนะนำด้านล่าง`;

        document.getElementById('errorCode').textContent = errorCodeText || 'Unknown Error';
        document.getElementById('errorMessage').textContent = errorMessageText || 'No additional information available.';

        // Create a new Modal instance every time
        const modalElement = document.getElementById('errorModal');
        const modalInstance = bootstrap.Modal.getInstance(modalElement);
        if (modalInstance) {
            modalInstance.dispose();
        }
        const newModal = new bootstrap.Modal(modalElement);
        newModal.show();
    }
}


// อัพเดท event listener สำหรับปิด Modal
document.getElementById('errorModal').addEventListener('hidden.bs.modal', function () {
    // ทำความสะอาด Modal instance เก่า
    const modalInstance = bootstrap.Modal.getInstance(this);
    if (modalInstance) {
        modalInstance.dispose();
    }
});
    