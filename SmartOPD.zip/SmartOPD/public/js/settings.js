const socket = io();

// เพิ่มตัวแปรสำหรับเก็บค่า config
let portConfig = null;
let displayConfig = null;
let colorConfig = null;

// รับค่า port config เมื่อโหลดหน้า
socket.on('portConfig', (config) => {
    portConfig = config;
    
    // อัพเดทค่าใน dropdown ตาม config
    if (config.ports) {
        if (config.ports.pressure) {
            document.getElementById('pressurePort').value = config.ports.pressure.path || '';
            document.getElementById('pressureBaudRate').value = config.ports.pressure.baudRate || '9600';
            document.getElementById('pressureModel').value = config.ports.pressure.model || 'inbody1';
        }
        if (config.ports.temp?.path) {
            document.getElementById('tempPort').value = config.ports.temp.path;
        }
    }
});

// รับค่า display config เมื่อโหลดหน้า
socket.on('displayConfig', (config) => {
    displayConfig = config;
    
    // อัพเดท checkbox ตาม config
    if (config && config.enabled) {
        // แมปื่อ checkbox กับค่าใน config
        const checkboxMapping = {
            'temperature': 'showTemp',
            'pressure': 'showPressure',
            'bmi': 'showBmi'
        };
        
        // อัพเดทสถานะ checkbox
        Object.entries(config.enabled).forEach(([page, enabled]) => {
            const checkboxId = checkboxMapping[page];
            const checkbox = document.getElementById(checkboxId);
            if (checkbox) {
                checkbox.checked = enabled;
            }
        });
    }
});
// แก้ไขการเรียก getDisplayConfig
document.addEventListener('DOMContentLoaded', () => {
    // ขอข้อมูล config จาก server พร้อม callback
    socket.emit('getDisplayConfig', (config) => {
        if (config) {
            displayConfig = config;
            
            // อัพเดท checkbox ตาม config
            if (config.enabled) {
                const checkboxMapping = {
                    'temperature': 'showTemp',
                    'pressure': 'showPressure',
                    'bmi': 'showBmi'
                };
                
                Object.entries(config.enabled).forEach(([page, enabled]) => {
                    const checkboxId = checkboxMapping[page];
                    const checkbox = document.getElementById(checkboxId);
                    if (checkbox) {
                        checkbox.checked = enabled;
                    }
                });
            }
        }
    });
});
// แก้ไขการทำงานของปุ่มรีเฟรชพอร์ต
document.getElementById('refreshPorts').addEventListener('click', async function() {
    // เปลี่ยนไอคอนปุ่มให้หมุน
    const icon = this.querySelector('i');
    icon.classList.add('rotate-animation');
    
    // ปิดการใช้งานปุ่มชั่วคราว
    this.disabled = true;
    
    try {
        // ยกเลิกการเชื่อมต่อทั้งหมดก่อน
        socket.emit('disconnectAllPorts');
        
        // รอสักครู่
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // ขอข้อมูลพอร์ตใหม่
        socket.emit('listPorts');
        
        // เชื่อมต่อพอร์ตที่เคยเชื่อมต่อไว้อีกครั้ง
        const pressurePort = document.getElementById('pressurePort').value;
        const tempPort = document.getElementById('tempPort').value;
        
        if (pressurePort) {
            const baudRate = parseInt(document.getElementById('pressureBaudRate').value);
            const model = document.getElementById('pressureModel').value;
            socket.emit('togglePort', { 
                type: 'pressure', 
                port: pressurePort, 
                baudRate,
                model,
                action: 'connect'
            });
        }
        
        if (tempPort) {
            socket.emit('togglePort', { 
                type: 'temp', 
                port: tempPort, 
                action: 'connect'
            });
        }
        
        showAlert('success', 'รีเฟรชพอร์ต', 'รีเซ็ตและเชื่อมต่อพอร์ตใหม่เรียบร้อยแล้ว');
    } catch (error) {
        showAlert('error', 'ข้อผิดพลาด', 'เกิดข้อผิดพลาดในการรีเฟรชพอร์ต');
    } finally {
        // เอาคลาสหมุนออกและเปิดใช้งานปุ่มอีกครั้ง
        icon.classList.remove('rotate-animation');
        this.disabled = false;
    }
});

// รับรายการพอร์ตและอัพเดท dropdown
socket.on('portList', (ports) => {
    const pressureSelect = document.getElementById('pressurePort');
    const tempSelect = document.getElementById('tempPort');
    const weightSelect = document.getElementById('weightPort');
    
    // ล้างตัวเลือกเดิม
    pressureSelect.innerHTML = '<option value="">เลือกพอร์ต</option>';
    tempSelect.innerHTML = '<option value="">เลือกพอร์ต</option>';
    weightSelect.innerHTML = '<option value="">เลือกพอร์ต</option>';
    
    // เพิ่มพอร์ตทั้งหมดที่เจอ
    ports.forEach(port => {
        const option = document.createElement('option');
        option.value = port.path;
        
        // แสดงข้อมูลพอร์ตแบบละเอียด
        const details = [];
        if (port.manufacturer) details.push(port.manufacturer);
        if (port.vendorId) details.push(`VID:${port.vendorId}`);
        if (port.productId) details.push(`PID:${port.productId}`);
        
        option.textContent = `${port.path}${details.length ? ` (${details.join(', ')})` : ''}`;
        
        // เพิ่มตัวเลือกในทักพอร์ต
        pressureSelect.appendChild(option.cloneNode(true));
        tempSelect.appendChild(option.cloneNode(true));
        weightSelect.appendChild(option.cloneNode(true));
    });
    
    // ตรวจสอบว่ามีพอร์ตที่บันทึกไว้หรือไม่
    if (portConfig?.ports) {
        if (portConfig.ports.pressure?.path) {
            pressureSelect.value = portConfig.ports.pressure.path;
        }
        if (portConfig.ports.temp?.path) {
            tempSelect.value = portConfig.ports.temp.path;
        }
        if (portConfig.ports.weight?.path) {
            weightSelect.value = portConfig.ports.weight.path;
            document.getElementById('weightBaudRate').value = portConfig.ports.weight.baudRate || '9600';
        }
    }
});

// แก้ไขส่วนการจัดการการเชื่อมต่อพอร์ต
document.getElementById('toggleAllPorts').addEventListener('click', async function() {
    const action = this.querySelector('span').textContent === 'เชื่อมต่อทั้งหมด' ? 'connect' : 'disconnect';
    
    if (action === 'connect') {
        // เก็บค่าการตั้งค่าพอร์ต
        const pressurePort = document.getElementById('pressurePort').value;
        const pressureBaudRate = parseInt(document.getElementById('pressureBaudRate').value);
        const model = document.getElementById('pressureModel').value;
        const tempPort = document.getElementById('tempPort').value;
        const weightPort = document.getElementById('weightPort').value;
        const weightBaudRate = parseInt(document.getElementById('weightBaudRate').value);

        // ตรวจสอบว่ามีการเลือกพอร์ตหรือไม่
        if (!pressurePort && !tempPort && !weightPort) {
            showAlert('warning', 'กรุณาเลือกพอร์ต', 'กรุณาเลือกพอร์ตที่ต้องการเชื่อมต่อ');
            return;
        }

        try {
            // บันทึกการตั้งค่าพอร์ตก่อน
            if (pressurePort) {
                await new Promise((resolve, reject) => {
                    socket.emit('savePortConfig', {
                        type: 'pressure',
                        config: {
                            path: pressurePort,
                            baudRate: pressureBaudRate,
                            model: model
                        }
                    });
                    socket.once('portConfigSaved', (response) => {
                        if (response.success) resolve();
                        else reject(new Error(response.error));
                    });
                });
            }

            if (tempPort) {
                await new Promise((resolve, reject) => {
                    socket.emit('savePortConfig', {
                        type: 'temp',
                        config: {
                            path: tempPort,
                            baudRate: 115200,
                            enabled: true
                        }
                    });
                    socket.once('portConfigSaved', (response) => {
                        if (response.success) resolve();
                        else reject(new Error(response.error));
                    });
                });
            }

            if (weightPort) {
                await new Promise((resolve, reject) => {
                    socket.emit('savePortConfig', {
                        type: 'weight',
                        config: {
                            path: weightPort,
                            baudRate: weightBaudRate,
                            enabled: true
                        }
                    });
                    socket.once('portConfigSaved', (response) => {
                        if (response.success) resolve();
                        else reject(new Error(response.error));
                    });
                });
            }

            // หลังจากบันทึกสำเร็จ ค่อยทำการเชื่อมต่อ
            if (pressurePort) {
                socket.emit('togglePort', { 
                    type: 'pressure', 
                    port: pressurePort, 
                    baudRate: pressureBaudRate,
                    enabled: true,
                    model,
                    action: 'connect'
                });
            }
            
            if (tempPort) {
                socket.emit('togglePort', { 
                    type: 'temp', 
                    port: tempPort, 
                    action: 'connect'
                });
            }

            if (weightPort) {
                socket.emit('togglePort', { 
                    type: 'weight', 
                    port: weightPort, 
                    baudRate: weightBaudRate,
                    action: 'connect'
                });
            }

        } catch (error) {
            showAlert('error', 'ข้อผิดพลาด', 'ไม่สามารถบันทึกการตั้งค่าพอร์ต: ' + error.message);
            return;
        }
    } else {
        // กรณียกเลิกการเชื่อมต่อ
        socket.emit('disconnectAllPorts');
    }
});

// แก้ไขส่วนการรับสถานะการเชื่อมต่อ
socket.on('connectionStatus', (status) => {
    const toggleBtn = document.getElementById('toggleAllPorts');
    const btnText = toggleBtn.querySelector('span');
    
    // ตัพเดทสถานะปุ่มแต่ละพอร์ต
    updatePortStatus('pressure', status.pressure);
    updatePortStatus('temp', status.temp);
    updatePortStatus('weight', status.weight);  // เพิ่มการอัพเดทสถานะเครื่องชั่ง
    
    // อัพเดทค่าในฟอร์ม
    if (status.pressure?.port) {
        document.getElementById('pressurePort').value = status.pressure.port;
        document.getElementById('pressureBaudRate').value = status.pressure.baudRate || '2400';
    }
    
    if (status.temp?.port) {
        document.getElementById('tempPort').value = status.temp.port;
    }
    
    if (status.weight?.port) {  // เพิ่มการอัพเดทค่าเครื่องชั่ง
        document.getElementById('weightPort').value = status.weight.port;
        document.getElementById('weightBaudRate').value = status.weight.baudRate || '9600';
    }
    
    // อัพเดทสถานะปุ่มเชื่อมต่อทั้งหมด
    const isAnyConnected = status.pressure?.connected || 
                          status.temp?.connected || 
                          status.weight?.connected;  // เพิ่มการตรวจสอบสถานะเครื่องชั่ง
    
    if (isAnyConnected) {
        btnText.textContent = 'ยกเลิกการเชื่อมต่อ';
        toggleBtn.classList.replace('btn-primary', 'btn-danger');
    } else {
        btnText.textContent = 'เชื่อมต่อทั้งหมด';
        toggleBtn.classList.replace('btn-danger', 'btn-primary');
    }
});

// เพิ่มฟังก์ชันอัพเดทสถานะพอร์ต
function updatePortStatus(type, status) {
    const portSelect = document.getElementById(`${type}Port`);
    const baudSelect = document.getElementById(`${type}BaudRate`);
    
    if (status?.connected) {
        portSelect.value = status.port;
        if (baudSelect) {  // บางพอร์ตอาจไม่มี baudRate
            baudSelect.value = status.baudRate;
        }
        portSelect.disabled = true;
        if (baudSelect) baudSelect.disabled = true;
    } else {
        portSelect.disabled = false;
        if (baudSelect) baudSelect.disabled = false;
    }
}

// เพิ่ม event listener สำหรับการเปลี่ยนแปลงค่าพอร์ต
document.getElementById('weightPort')?.addEventListener('change', function() {
    const baudSelect = document.getElementById('weightBaudRate');
    if (this.value) {
        baudSelect.disabled = false;
    } else {
        baudSelect.disabled = true;
    }
});

// เพิ่มฟังก์ชันเชื่อมต่ออัตโนมัติ
function autoConnect() {
    if (portConfig?.ports) {
        if (portConfig.ports.pressure?.path) {
            socket.emit('togglePort', {
                type: 'pressure',
                port: portConfig.ports.pressure.path,
                baudRate: portConfig.ports.pressure.baudRate,  // เพิ่ม baudRate
                model: portConfig.ports.pressure.model,
                action: 'connect'
            });
        }
        if (portConfig.ports.temp?.path) {
            socket.emit('togglePort', {
                type: 'temp',
                port: portConfig.ports.temp.path,
                baudRate: portConfig.ports.temp.baudRate,  // เพิ่ม baudRate
                action: 'connect'
            });
        }
        if (portConfig.ports.weight?.path) {  // เพิ่มการเอ่ช
            socket.emit('togglePort', {
                type: 'weight',
                port: portConfig.ports.weight.path,
                baudRate: portConfig.ports.weight.baudRate,
                action: 'connect'
            });
        }
    }
}


// โหลดข้อมูลเมื่อเริ่มต้น
socket.emit('getPorts');
socket.emit('getPortConfig');

// เพิ่ม event listeners สำหรับฟอร์มฐานข้อมูล
document.getElementById('saveDbSettings').addEventListener('click', async function() {
    const settings = {
        host: document.getElementById('dbHost').value,
        user: document.getElementById('dbUser').value,
        password: document.getElementById('dbPassword').value,
        primaryDatabase: document.getElementById('primaryDbName').value,
        secondaryDatabase: document.getElementById('secondaryDbName').value,
        useSecondaryDb: document.getElementById('useSecondaryDb').checked
    };

    // ตรวจสอบข้อมูล
    if (!settings.host || !settings.user || !settings.primaryDatabase) {
        showAlert('warning', 'กรุณากรอกข้อมูล', 'กรุณากรอกข้อมูลการเชื่อมต่อและชื่อฐานข้อมูลหลักให้ครบถ้วน');
        return;
    }

    // ตรวจสอบฐานข้อมูลรองถ้าเปิดใช้งาน
    if (settings.useSecondaryDb && !settings.secondaryDatabase) {
        showAlert('warning', 'กรุณากรอกข้อมูล', 'กรุณากรอกชื่อฐานข้อมูลรองเมื่อเปิดใช้งานฐานข้อมูลที่สอง');
        return;
    }

    try {
        // ทดสอบการเชื่อมต่อก่อน
        socket.emit('testDbConnection', settings);
        
        // รอผลการทดสอบการเชื่อมต่อ
        const testResult = await new Promise((resolve) => {
            socket.once('dbTestResult', resolve);
        });

        if (!testResult.success) {
            showAlert('error', 'ข้อผิดพลาด', 'ไม่สามารถเชื่อมต่อฐานข้อมูล: ' + testResult.error);
            return;
        }

        // ถ้าเชื่อมต่อได้ ให้บันทึกการตั้งค่า
        socket.emit('saveDbSettings', settings);

        // แสดง loading alert
        showAlert('info', 'กำลังดำเนินการ', 'กำลังบันทึกการตั้งค่าและรีสตาร์ทเซิร์ฟเวอร์...');
        
    } catch (error) {
        showAlert('error', 'ข้อผิดพลาด', 'เกิดข้อผิดพลาด: ' + error.message);
    }
});

// รับผลการบันทึก
socket.on('dbSettingsSaved', (response) => {
    if (response.success) {
        showAlert('success', 'บันทึกการตั้งค่า', 'บันทึกการตั้งค่าฐานข้อมูลเรียบร้อยแล้ว กำลังรีสตาร์ทเซิร์ฟเวอร์...');
    } else {
        showAlert('error', 'บันทึกการตั้งค่า', 'ไม่สามารถบันทึกการตั้งค่า: ' + response.error);
    }
});

// รับการตั้งค่าเมื่อโหลดหน้า
socket.on('dbSettings', (settings) => {
    if (settings) {
        document.getElementById('dbHost').value = settings.host || '';
        document.getElementById('dbUser').value = settings.user || '';
        document.getElementById('dbPassword').value = settings.password || '';
        document.getElementById('primaryDbName').value = settings.primaryDatabase || '';
        document.getElementById('secondaryDbName').value = settings.secondaryDatabase || '';
        document.getElementById('useSecondaryDb').checked = settings.useSecondaryDb || false;
        
        // แสดง/ซ่อนส่วนฐานข้อมูลรองตามสถานะสวิตช์
        toggleSecondaryDbSection(settings.useSecondaryDb);
    }
});

// เพิ่มฟังก์ชันสำหรับแสดง/ซ่อนส่วนฐานข้อมูลรอง
function toggleSecondaryDbSection(show) {
    const secondaryDbSection = document.getElementById('secondaryDbSection');
    secondaryDbSection.style.display = show ? 'block' : 'none';
}

// เพิ่ม event listener สำหรับสวิตช์
document.getElementById('useSecondaryDb').addEventListener('change', function() {
    toggleSecondaryDbSection(this.checked);
});

// ขอการตั้งค่าเมื่อโหลดหน้า
socket.emit('getDbSettings');

// จัดการข้อผิดพลาด
socket.on('dbError', (error) => {
    console.error('Database error:', error);
    alert('เกิดข้อผิดพลาด: ' + error);
});

// เพิ่ม event listeners สำหรับการแจ้งเตืนนเมื่อบันทึกสำเร็จ
socket.on('portError', (data) => {
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-warning';
    alertDiv.textContent = data.message;
    document.querySelector('.container').prepend(alertDiv);
    
    setTimeout(() => alertDiv.remove(), 3000);
});

socket.on('portSuccess', (data) => {
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-success';
    alertDiv.textContent = data.message;
    document.querySelector('.container').prepend(alertDiv);
    
    setTimeout(() => alertDiv.remove(), 3000);
});

document.getElementById('pressureBaudRate').innerHTML = `
    <option value="2400">2400</option>
    <option value="4800">4800</option>
    <option value="9600">9600</option>
    <option value="1200">1200</option>
`;

// เพิ่มการจัดการสี
function initColorSettings() {
    // อัพเดทค่าที่แสดงเมื่อเลื่อน range
    ['sys', 'dia'].forEach(type => {
        ['Low', 'High'].forEach(level => {
            const range = document.getElementById(`${type}${level}Range`);
            const value = document.getElementById(`${type}${level}Value`);
            range.addEventListener('input', () => {
                value.textContent = range.value;
            });
        });
    });
}

// บันทึกการตั้งี
document.getElementById('saveColorSettings').addEventListener('click', () => {
    const settings = {
        temp: {
            feverThreshold: parseFloat(document.getElementById('tempFever').value),
            normalColor: document.getElementById('tempNormalColor').value,
            feverColor: document.getElementById('tempFeverColor').value
        },
        sys: {
            low: parseInt(document.getElementById('sysLow').value),
            high: parseInt(document.getElementById('sysHigh').value),
            lowColor: document.getElementById('sysLowColor').value,
            normalColor: document.getElementById('sysNormalColor').value,
            highColor: document.getElementById('sysHighColor').value
        },
        dia: {
            low: parseInt(document.getElementById('diaLow').value),
            high: parseInt(document.getElementById('diaHigh').value),
            lowColor: document.getElementById('diaLowColor').value,
            normalColor: document.getElementById('diaNormalColor').value,
            highColor: document.getElementById('diaHighColor').value
        },
        bmi: {
            lowColor: document.getElementById('lowBmiColor').value,
            normalColor: document.getElementById('normalBmiColor').value,
            highColor: document.getElementById('highBmiColor').value,
            dangerColor: document.getElementById('dangerBmiColor').value
        }
    };

    // บันทึกการตั้งค่าและรีโหลดค่าใหม่
    socket.emit('saveColorConfig', settings, (response) => {
        if (response.success) {
            showAlert('success', 'สำเร็จ', 'บันทึกการตั้งค่าสีเรียบร้อยแล้ว');
            // ดึงค่า config ใหม่หลังจากบันทึก
            socket.emit('getColorConfig');
        } else {
            showAlert('error', 'ข้อผิดพลาด', 'ไม่สามารถบันทึกการตั้งค่าสี');
        }
    });
});

socket.on('colorConfig', (settings) => {
    console.log('Received color config:', settings);
    
    if (settings) {
        // อัพเดทค่าและสีสำหรับอุณหภูมิ
        if (settings.temp) {
            document.getElementById('tempFever').value = settings.temp.feverThreshold;
            document.getElementById('tempNormalColor').value = settings.temp.normalColor;
            document.getElementById('tempFeverColor').value = settings.temp.feverColor;
            
       
        }

        // อัพเดทค่าและสีสำหรับความดันตัวบน (SYS)
        if (settings.sys) {
            document.getElementById('sysLow').value = settings.sys.low;
            document.getElementById('sysHigh').value = settings.sys.high;
            document.getElementById('sysLowColor').value = settings.sys.lowColor;
            document.getElementById('sysNormalColor').value = settings.sys.normalColor;
            document.getElementById('sysHighColor').value = settings.sys.highColor;
            
          
        }

        // อัพเดทค่าและสีสำหรับความดันตัวล่าง (DIA)
        if (settings.dia) {
            document.getElementById('diaLow').value = settings.dia.low;
            document.getElementById('diaHigh').value = settings.dia.high;
            document.getElementById('diaLowColor').value = settings.dia.lowColor;
            document.getElementById('diaNormalColor').value = settings.dia.normalColor;
            document.getElementById('diaHighColor').value = settings.dia.highColor;
            
          
        }
    }
});


// เพิ่ม Event Listeners เมื่อโหลดหน้า
document.addEventListener('DOMContentLoaded', () => {
    // ดึงค่า config เมื่อโหลดหน้า
    socket.emit('getColorConfig');
    
    // เพิ่ม event listeners สำหรับการเปลี่ยนสี
    const colorInputs = [
        'tempNormalColor', 'tempFeverColor',
        'sysLowColor', 'sysNormalColor', 'sysHighColor',
        'diaLowColor', 'diaNormalColor', 'diaHighColor'
    ];

    colorInputs.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.addEventListener('input', (e) => {
                e.target.style.backgroundColor = e.target.value;
                updateAlertPreview();
            });
        }
    });
});


// อัพเดทฟังก์ชันรับการตั้งค่าสี
socket.on('colorSettings', (settings) => {
    if (settings) {
        ['temp', 'sys', 'dia', 'pr'].forEach(type => {
            if (settings[type]) {
                const colorInput = document.getElementById(`${type}Color`);
                if (colorInput) {
                    colorInput.value = settings[type].color;
                    updateColorPreview(type, settings[type].color);
                }
            }
        });
    }
});

// แก้ไขการแจ้งเตือนเมื่อบันทึกสำเร็จ
socket.on('colorSettingsSaved', (response) => {
    if (response.success) {
        showAlert(
            'success',
            'บันทึกการตั้งค่าสีเรียบร้อยแล้ว'
        );
    } else {
        showAlert(
            'error',
            'ข้อผิดพลาด',
            'ไม่สามารถบันทึกการตั้งค่าสี: ' + (response.error || 'เกิดข้อผิดพลาดที่ไม่ทราบสาเหตุ')
        );
    }
});

// เพิ่มฟังก์ชันโหลดการตั้งค่าสีเมื่อเริ่มต้น
function loadColorSettings() {
    socket.emit('getColorConfig', (config) => {
        if (config) {
            // อัพเดทค่าอุณหภูมิ
            if (config.temp) {
                document.getElementById('tempFever').value = config.temp.feverThreshold;
                document.getElementById('tempNormalColor').value = config.temp.normalColor;
                document.getElementById('tempFeverColor').value = config.temp.feverColor;
                
                // อั���เดทสีพื้นหลังขอ input
                document.getElementById('tempNormalColor').style.backgroundColor = config.temp.normalColor;
                document.getElementById('tempFeverColor').style.backgroundColor = config.temp.feverColor;
            }

            // อัพเดทค่าความดันตัวบน (SYS)
            if (config.sys) {
                document.getElementById('sysLow').value = config.sys.low;
                document.getElementById('sysHigh').value = config.sys.high;
                document.getElementById('sysLowColor').value = config.sys.lowColor;
                document.getElementById('sysNormalColor').value = config.sys.normalColor;
                document.getElementById('sysHighColor').value = config.sys.highColor;
                
                // อัพเดทสีพื้นหลังของ input
                document.getElementById('sysLowColor').style.backgroundColor = config.sys.lowColor;
                document.getElementById('sysNormalColor').style.backgroundColor = config.sys.normalColor;
                document.getElementById('sysHighColor').style.backgroundColor = config.sys.highColor;
            }

            // อัพเดทค่าความดันตัวล่าง (DIA)
            if (config.dia) {
                document.getElementById('diaLow').value = config.dia.low;
                document.getElementById('diaHigh').value = config.dia.high;
                document.getElementById('diaLowColor').value = config.dia.lowColor;
                document.getElementById('diaNormalColor').value = config.dia.normalColor;
                document.getElementById('diaHighColor').value = config.dia.highColor;
                
                // อัพเดทสีพื้นหลังของ input
                document.getElementById('diaLowColor').style.backgroundColor = config.dia.lowColor;
                document.getElementById('diaNormalColor').style.backgroundColor = config.dia.normalColor;
                document.getElementById('diaHighColor').style.backgroundColor = config.dia.highColor;
            }
            if (config.bmi) {
                document.getElementById('lowBmiColor').value = config.bmi.lowColor;
                document.getElementById('normalBmiColor').value = config.bmi.normalColor;
                document.getElementById('highBmiColor').value = config.bmi.highColor;
                document.getElementById('dangerBmiColor').value = config.bmi.dangerColor;
            }
        }
    });
}

// เพิ่ม Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    // โหลดการตั้งค่าเมื่อโหลดหน้า
    loadColorSettings();
    
    // เพิ่ม event listener สำหรับการเปลี่ยนแปลงสี
    const colorInputs = [
        'tempNormalColor', 'tempFeverColor',
        'sysLowColor', 'sysNormalColor', 'sysHighColor',
        'diaLowColor', 'diaNormalColor', 'diaHighColor',
        'lowBmiColor', 'normalBmiColor', 'highBmiColor', 'dangerBmiColor'
    ];

    colorInputs.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.addEventListener('input', (e) => {
                e.target.style.backgroundColor = e.target.value;
                updateAlertPreview();
            });
        }
    });
});


// เพิ่ม Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    // Event listeners สำหรับการเปลี่ยนแปลงค่าต่างๆ
    ['sysLow', 'sysHigh', 'diaLow', 'diaHigh'].forEach(id => {
        document.getElementById(id).addEventListener('input', updateAlertPreview);
    });

    ['sysLowColor', 'sysNormalColor', 'sysHighColor', 
     'diaLowColor', 'diaNormalColor', 'diaHighColor',
     'lowBmiColor', 'normalBmiColor', 'highBmiColor', 'dangerBmiColor'
     ].forEach(id => {
        document.getElementById(id).addEventListener('input', updateAlertPreview);
    });

    // บันทึกการตังค่าจ้งเตือน
    document.getElementById('saveAlertSettings').addEventListener('click', () => {
        const settings = {
            sys: {
                low: parseInt(document.getElementById('sysLow').value),
                high: parseInt(document.getElementById('sysHigh').value),
                lowColor: document.getElementById('sysLowColor').value,
                normalColor: document.getElementById('sysNormalColor').value,
                highColor: document.getElementById('sysHighColor').value
            },
            dia: {
                low: parseInt(document.getElementById('diaLow').value),
                high: parseInt(document.getElementById('diaHigh').value),
                lowColor: document.getElementById('diaLowColor').value,
                normalColor: document.getElementById('diaNormalColor').value,
                highColor: document.getElementById('diaHighColor').value
            },
            bmi: {
                lowColor: document.getElementById('lowBmiColor').value,
                normalColor: document.getElementById('normalBmiColor').value,
                highColor: document.getElementById('highBmiColor').value,
                dangerColor: document.getElementById('dangerBmiColor').value
            }
        };

        socket.emit('saveAlertSettings', settings);
    });

    // โหลดการตั้งค่าเมื่อเปิดหน้า
    socket.emit('getAlertSettings');
});

// รับการตั้งค่าจาก server
socket.on('alertSettings', (settings) => {
    if (settings) {
        document.getElementById('sysLow').value = settings.sys.low;
        document.getElementById('sysHigh').value = settings.sys.high;
        document.getElementById('sysLowColor').value = settings.sys.lowColor;
        document.getElementById('sysNormalColor').value = settings.sys.normalColor;
        document.getElementById('sysHighColor').value = settings.sys.highColor;

        document.getElementById('diaLow').value = settings.dia.low;
        document.getElementById('diaHigh').value = settings.dia.high;
        document.getElementById('diaLowColor').value = settings.dia.lowColor;
        document.getElementById('diaNormalColor').value = settings.dia.normalColor;
        document.getElementById('diaHighColor').value = settings.dia.highColor;

        document.getElementById('lowBmiColor').value = settings.bmi.lowColor;
        document.getElementById('normalBmiColor').value = settings.bmi.normalColor;
        document.getElementById('highBmiColor').value = settings.bmi.highColor;
        document.getElementById('dangerBmiColor').value = settings.bmi.dangerColor;

        updateAlertPreview();
    }
});

// แยกการจัดการ event listeners ออกเป็นส่วนๆ
function initializeEventListeners() {
    // จัดการ staff settings
    initStaffSettings();
    
    // จัดการ color settings
    initColorSettings();
}

// เพิ่มฟังก์ชันสำหรับจัดการการตั้งค่าเจ้าหน้าที่
function initStaffSettings() {
    const saveStaffBtn = document.getElementById('saveStaffSettings');
    const staffNameInput = document.getElementById('staffName');
    
    if (saveStaffBtn && staffNameInput) {
        saveStaffBtn.addEventListener('click', async () => {
            const staffName = staffNameInput.value.trim();
            
            if (!staffName) {
                showAlert('warning', 'กรุณากรอกข้อมูล', 'กรุณากรอกชื่อเจ้าหน้าที่');
                return;
            }
            
            try {
                // ส่งข้อมูลใ��รูปบบ JSON
                const response = await fetch('/staff-settings', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        staffName: staffName
                    })
                });

                if (!response.ok) {
                    const errorText = await response.text();
                    throw new Error(errorText || 'Network response was not ok');
                }
                
                const data = await response.json();
                
                if (data.success) {
                    showAlert('success', 'บันทึกข้อมูล', 'บันทึกข้อมูลเจ้าหน้าที่เรียบร้อยแล้ว');
                    loadStaffSettings();
                } else {
                    showAlert('error', 'ข้อผิดพลาด', data.error || 'ไม่สามารถบันทึกข้อมูลได้');
                }
            } catch (error) {
                console.error('Error saving staff settings:', error);
                showAlert('error', 'ข้อผิดพลาด', 'เกิดข้อผิดพลาดในการบันทึกข้อมูล');
            }
        });
    }
}

// ฟังก์ชันโหลดข้อมูลเจ้าหน้าที่
async function loadStaffSettings() {
    try {
        const response = await fetch('/api/staff-settings');
        const data = await response.json();
        if (data.success && data.settings) {
            document.getElementById('staffName').value = data.settings.staffName || '';
        }
    } catch (error) {
        console.error('Error loading staff settings:', error);
    }
}
function initColorSettings() {
    const colorForm = document.getElementById('colorSettingsForm');
    const saveColorBtn = document.getElementById('saveColorSettings');
    
    // ตรวจสอบว่ามีฟอร์มอยู่จริงก่อนเพิ่ม event listeners
    if (colorForm && saveColorBtn) {
        // เพิ่ม event listeners สำหรับการตั้งค่าสี
        saveColorBtn.addEventListener('click', function() {
            // ... existing color settings code ...
        });
        
        // ... other color-related event listeners ...
    }
}
// เรียกใช้ฟังก์ชันเมื่อ DOM โหลดเสร็จ
document.addEventListener('DOMContentLoaded', () => {
    initStaffSettings();
    loadStaffSettings();
});

// แก้ขส่วนการจัดการกานข้อมูล
document.getElementById('testDbConnection').addEventListener('click', function() {
    const settings = getDbSettings();
    if (!validateDbSettings(settings)) return;
    
    socket.emit('testDbConnection', settings);
});

document.getElementById('saveDbSettings').addEventListener('click', function() {
    const settings = getDbSettings();
    if (!validateDbSettings(settings)) return;
    
    socket.emit('saveDbSettings', settings);
});

// เพิ่มฟังก์ชันดึงค่าการตั้งค่าฐานข้อมูล
function getDbSettings() {
    return {
        host: document.getElementById('dbHost').value,
        user: document.getElementById('dbUser').value,
        password: document.getElementById('dbPassword').value,
        primaryDatabase: document.getElementById('primaryDbName').value,
        secondaryDatabase: document.getElementById('secondaryDbName').value,
        useSecondaryDb: document.getElementById('useSecondaryDb').checked
    };
}

// เพิ่มฟังก์ชันตรวจสอบความถูกต้อง
function validateDbSettings(settings) {
    if (!settings.host || !settings.user || !settings.primaryDatabase) {
        showAlert('warning', 'กรุณากรอกข้อมูล', 'กรุณากรอกข้อมูลการเชื่อมต่อและชื่อฐานข้อมูลหลักให้ครบถ้วน');
        return false;
    }
    
    if (settings.useSecondaryDb && !settings.secondaryDatabase) {
        showAlert('warning', 'กรุณากรอกข้อมูล', 'กรุณากรอกชื่อฐานข้อมูลรองเมื่อเปิดใช้งานฐานข้อมูลที่สอง');
        return false;
    }
    
    return true;
}

// แก้ไขการแสดงการแจ้งเตือนให้ใช้ Modal
function showAlert(type, title, message) {
    const modal = new bootstrap.Modal(document.getElementById('alertModal'));
    const modalContent = document.querySelector('#alertModal .modal-content');
    const modalTitle = document.querySelector('#alertModal .modal-title');
    const modalBody = document.querySelector('#alertModal .modal-body');
    
    // ซ่อนปุ่มปิดและ footer
    document.querySelector('#alertModal .btn-close').style.display = 'none';
    document.querySelector('#alertModal .modal-footer').style.display = 'none';
    
    modalContent.className = 'modal-content';
    modalBody.innerHTML = '';

    switch(type) {
        case 'success':
            modalContent.classList.add('border-success');
            modalTitle.innerHTML = `<i class="bi bi-check-circle text-success"></i> ${title}`;
            modalBody.innerHTML = `
                <div class="success-checkmark">
                    <div class="check-icon">
                        <span class="icon-line line-tip"></span>
                        <span class="icon-line line-long"></span>
                        <div class="icon-circle"></div>
                        <div class="icon-fix"></div>
                    </div>
                    <div class="text-center mt-3">${message || 'ดำเนินการเสร็จสิ้น'}</div>
                </div>
            `;
            break;
        case 'info':
            modalContent.classList.add('border-info');
            modalTitle.innerHTML = `<i class="bi bi-info-circle text-info"></i> ${title}`;
            modalBody.innerHTML = `
                <div class="text-center">
                    <div class="spinner-border text-info mb-3" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <div>${message || 'กำลังดำเนินการ...'}</div>
                </div>
            `;
            break;
        case 'warning':
            modalContent.classList.add('border-warning');
            modalTitle.innerHTML = `<i class="bi bi-exclamation-triangle text-warning"></i> ${title}`;
            modalBody.textContent = message || 'รุณาตรวจสอบข้อมูล';
            break;
        case 'error':
            modalContent.classList.add('border-danger');
            modalTitle.innerHTML = `<i class="bi bi-x-circle text-danger"></i> ${title}`;
            modalBody.textContent = message || 'เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง';
            break;
    }
    
    modal.show();
    
    // ถ้าเป็น success หรือ error ให้ปิดอัตโนมัติหลัง 3 วินาที
    if (type === 'success' || type === 'error') {
        setTimeout(() => modal.hide(), 3000);
    }
}

// รับผลการทดสอบการเชื่อมต่อ
socket.on('dbTestResult', (response) => {
    if (response.success) {
        showAlert('success', 'ทดสอบกรเชื่อมต่อ', 'เชื่อมต่อฐานข้อมูลสำเร็จ');
    } else {
        showAlert('error', 'ทดสอบการเชื่อมต่อ', 'ไม่สามารถเชื่อมต่อฐานข้อมูล: ' + response.error);
    }
});

// เพิ่ม event listener สำหรับการรีสตาร์ทเซิร์ฟเวอร์
socket.on('serverRestarting', () => {
    showAlert('info', 'กำลังรีสตาร์ทเซิร์ฟเวอร์', 'กรุณารอสักครู่...');
    
    // รอ 3 วินาทีแล้วรีโหลดหน้า
    setTimeout(() => {
        window.location.reload();
    }, 3000);
});

// เพิ่ม event listener สำหรับมื่อเซิฟเวอร์พร้อมใช้งาน
socket.on('serverReady', (data) => {
    if (data.success) {
        showAlert('success', 'เซิฟเวอร์พร้อมใช้งาน', 'รีสตาร์ทเซิฟ์ฟเวอร์เสร็จสมูรณ์');
    }
});

// เพิ่มที่ส่วนบนของไฟล์
let displayOrderList;

// เพิ่มในฟังก์ชัน initializeEventListeners
function initializeEventListeners() {
    // ... existing code ...
    
    // เพิ่มการจัดการ display order
    initDisplayOrder();
}

function initDisplayOrder() {
    displayOrderList = new Sortable(document.getElementById('displayOrder'), {
        animation: 150,
        handle: '.bi-grip-vertical',
        ghostClass: 'sortable-ghost'
    });

    // Event listener สำหรับการบันทึกลำดับ
    document.getElementById('saveDisplayOrder').addEventListener('click', saveDisplayOrder);
    
    // Event listeners สำหรับ checkboxes
    ['Temp', 'Pressure', 'Bmi'].forEach(page => {
        const checkbox = document.getElementById(`show${page}`);
        if (checkbox) {
            checkbox.addEventListener('change', function() {
                const item = document.querySelector(`[data-page="${page.toLowerCase()}"]`);
                if (item) {
                    item.style.opacity = this.checked ? '1' : '0.5';
                }
            });
        }
    });
}

function saveDisplayConfig() {
    const config = {
        enabled: {
            temperature: document.getElementById('showTemp').checked,
            pressure: document.getElementById('showPressure').checked,
            bmi: document.getElementById('showBmi').checked
        },
        order: []
    };

    // เพิ่มลำดับตามที่เลือก
    if (config.enabled.temperature) config.order.push('temperature');
    if (config.enabled.pressure) config.order.push('pressure');
    if (config.enabled.bmi) config.order.push('bmi');

    // เพิ่ม callback function ในการเรียก emit
    socket.emit('saveDisplayConfig', config, (response) => {
        if (response.success) {
            showAlert('success', 'สำเร็จ', 'บันทึกการตั้งค่าเรียบร้อยแล้ว');
        } else {
            showAlert('error', 'ข้อผิดพลาด', 'ไม่สามารถบันทึกการตั้งค่าได้');
        }
    });
}

// เพิ่ม event listener สำหรับปุ่มบันทึก
document.getElementById('saveDisplayConfig').addEventListener('click', saveDisplayConfig);

// เพิ่ม event listener สำหรับการอัพเดทสถานะการแสดงผล
socket.on('displayConfigUpdated', (config) => {
    if (config && config.enabled) {
        // อัพเดทการแสดงผลทันทีที่มีการเปลี่ยนแปลง
        Object.entries(config.enabled).forEach(([page, enabled]) => {
            // อัพเดท checkbox
            const checkbox = document.getElementById(`show${page.charAt(0).toUpperCase() + page.slice(1)}`);
            if (checkbox) {
                checkbox.checked = enabled;
            }
            
            // ส่งคำสั่งไปยังหน้าหลักเพื่ออัพเดทการแสดงผล
            socket.emit('updatePageVisibility', {
                page: page,
                visible: enabled
            });
        });
    }
});

// แก้ไขฟังก์ชัน startCountdown ในหน้าสุดท้าย
function startCountdown() {
    const skipButton = document.getElementById('skipButton');
    if (skipButton) {
        skipButton.style.display = 'none';
    }
    
    let countdown = 3;
    const countdownDiv = document.createElement('div');
    countdownDiv.className = 'text-center mt-3';
    
    socket.emit('getDisplayConfig', (config) => {
        const enabledPages = config.order.filter(page => config.enabled[page]);
        const lastPage = enabledPages[enabledPages.length - 1];
        const currentPage = getCurrentPage(); // ฟังก์ชันที่ส่งคืนชื่อหน้าปัจจุบัน

        if (currentPage === lastPage) {
            countdownDiv.innerHTML = `
                <div class="saving-message">
                    <div class="spinner-border text-primary mb-2" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <h5>กำลังบันทึกข้อมูล... (${countdown})</h5>
                </div>
            `;
            
            document.querySelector('.reading-box').appendChild(countdownDiv);

            const countdownInterval = setInterval(() => {
                countdown--;
                countdownDiv.querySelector('h5').textContent = `กำลังบันทึกข้อมูล... (${countdown})`;
                
                if (countdown <= 0) {
                    clearInterval(countdownInterval);
                    window.location.href = '/thankyou';  // redirect ไปหน้าขอคุณ
                }
            }, 1000);
        } else {
            // โค้ดสำหรับหน้าอื่นๆ ที่ไม่ใช่หน้าสุดท้าย
            window.location.href = '/next-page?from=' + currentPage;
        }
    });
}

// ฟังก์ชันสำรับรับชื่อหน้าปัจจุบัน
function getCurrentPage() {
    const path = window.location.pathname;
    return path.substring(1); // ตัด / ออกาก path
}

// แก้ไขการจัดการปุ่มข้าม
document.getElementById('skipButton')?.addEventListener('click', () => {
    socket.emit('getDisplayConfig', (config) => {
        const enabledPages = config.order.filter(page => config.enabled[page]);
        const lastPage = enabledPages[enabledPages.length - 1];
        const currentPage = getCurrentPage();

        if (currentPage === lastPage) {
            // ถ้าเป็นหน้าสุดท้าย ให้ไปหน้าขอบคุณ
            window.location.href = '/thankyou';
        } else {
            // ถ้าไมใช่หน้าสุดท้าย ให้ไปหน้าถัดไป
            window.location.href = '/next-page?from=' + currentPage;
        }
    });
});

// เพิ่มการจัดการรูปภาพและชื่อโรงพยาบาล
document.getElementById('welcomeImage').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('welcomeImagePreview').src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
});

// บันทึกการตั้งค่าหน้าต้อนรับ
document.getElementById('welcomeSettingsForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData();
    formData.append('hospitalName', document.getElementById('hospitalName').value);
    
    const imageFile = document.getElementById('welcomeImage').files[0];
    if (imageFile) {
        formData.append('welcomeImage', imageFile);
    }

    try {
        const response = await fetch('/api/welcome-settings', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert('success', 'สำเร็จ', 'บันทึกการตั้งค่าเรียบร้อยแล้ว');
            
            // อัพเดตรูปภาพพรีวิวทันที
            if (data.imagePath) {
                document.getElementById('welcomeImagePreview').src = 
                    `${data.imagePath}?t=${new Date().getTime()}`;
            }
            
            // แจ้ง socket เพื่ออัพเดตหน้าอื่นๆ
            socket.emit('welcomeSettingsUpdated', {
                hospitalName: document.getElementById('hospitalName').value,
                welcomeImage: data.imagePath
            });
            
            // โหลดการตั้งค่าใหม่
            loadWelcomeSettings();
        } else {
            showAlert('error', 'ข้อผิดพลาด', data.error || 'ไม่สามารถบันทึกการตั้งค่าได้');
        }
    } catch (error) {
        console.error('Error saving welcome settings:', error);
        showAlert('error', 'ข้อผิดพลาด', 'เกิดข้อผิดพลาดในการบันทึกข้อมูล');
    }
});

// รับค่าการตั้งค่าเมื่อโหลดหน้า
socket.on('welcomeSettings', (settings) => {
    if (settings) {
        document.getElementById('hospitalName').value = settings.hospitalName || '';
        if (settings.welcomeImage) {
            document.getElementById('welcomeImagePreview').src = 
                `${settings.welcomeImage}?t=${new Date().getTime()}`;
        }
    }
});

// เพิ่มฟังก์ชันสำหรับโหลดการตั้งค่าเริ่มต้น
async function loadWelcomeSettings() {
    try {
        const response = await fetch('/api/welcome-settings');
        const data = await response.json();
        
        if (data.success && data.settings) {
            const settings = data.settings;
            const hospitalNameInput = document.getElementById('hospitalName');
            const welcomeImagePreview = document.getElementById('welcomeImagePreview');

            if (hospitalNameInput) {
                hospitalNameInput.value = settings.hospitalName || '';
            }

            if (welcomeImagePreview && settings.welcomeImage) {
                const timestamp = new Date().getTime();
                welcomeImagePreview.src = `${settings.welcomeImage}?t=${timestamp}`;
            }
        }
    } catch (error) {
        console.error('Error loading welcome settings:', error);
    }
}

// เรียกใช้ฟังก์ชันเมื่อโหลดน้า
document.addEventListener('DOMContentLoaded', loadWelcomeSettings);

// เพิ่ม event listener สำหรับการอัพเดต
socket.on('welcomeSettingsUpdated', (settings) => {
    if (!settings) return;

    try {
        const hospitalNameInput = document.getElementById('hospitalName');
        const welcomeImagePreview = document.getElementById('welcomeImagePreview');

        if (hospitalNameInput) {
            hospitalNameInput.value = settings.hospitalName || '';
        }

        if (welcomeImagePreview && settings.welcomeImage) {
            const timestamp = new Date().getTime();
            const imagePath = settings.welcomeImage.startsWith('/uploads/') 
                ? settings.welcomeImage 
                : `/uploads/${settings.welcomeImage}`;
                
            console.log('Loading image from:', imagePath);
            welcomeImagePreview.src = `${imagePath}?t=${timestamp}`;
            
            welcomeImagePreview.onerror = function() {
                console.error('Failed to load image:', this.src);
                this.src = '/images/1.webp';
            };

            welcomeImagePreview.onload = function() {
                console.log('Image loaded successfully:', this.src);
            };
        }
    } catch (error) {
        console.error('Error updating welcome settings:', error);
    }
});

// เพิ่ม event listener สำหรับปุ่มเชื่อมต่อเครื่องชั่ง
document.getElementById('toggleWeightPort')?.addEventListener('click', async function() {
    const weightPort = document.getElementById('weightPort').value;
    const weightBaudRate = parseInt(document.getElementById('weightBaudRate').value);
    
    if (!weightPort) {
        showAlert('warning', 'กรุณาเลือกพอร์ต', 'กรุณาเลือกพอร์ตเครื่องชั่งที่ต้องการเชื่อมต่อ');
        return;
    }

    try {
        // บันทึกการตั้งค่าพอร์ตเครื่องชั่ง
        await new Promise((resolve, reject) => {
            socket.emit('savePortConfig', {
                type: 'weight',
                config: {
                    path: weightPort,
                    baudRate: weightBaudRate
                }
            });
            socket.once('portConfigSaved', (response) => {
                if (response.success) resolve();
                else reject(new Error(response.error));
            });
        });

        // เช่อมต่อพอร์ตเครื่องชั่ง
        socket.emit('togglePort', { 
            type: 'weight', 
            port: weightPort, 
            baudRate: weightBaudRate,
            action: 'connect'
        });

    } catch (error) {
        showAlert('error', 'ข้อผิดพลาด', 'ไม่สามารถบันทึกการตั้งค่าพอร์ตเครื่องชั่ง: ' + error.message);
    }
});

// เพิ่มฟังก์ชันสำหรับจัดการวิดีโอ
async function initVideoManagement() {
    // โหลดรายการวิดีโอเมื่อเริ่มต้น
    await loadVideoList();
    
    // เพิ่ม event listener สำหรับการอัพโหลดวิดีโอ
    const videoUpload = document.getElementById('videoUpload');
    if (videoUpload) {
        videoUpload.addEventListener('change', handleVideoUpload);
    }
}
async function loadVideoList() {
    try {
        const response = await fetch('/api/videos');
        const data = await response.json();
        
        const videoList = document.getElementById('videoList');
        if (!videoList) return;
        
        videoList.innerHTML = '';
        
        if (data.success && data.videos && data.videos.length > 0) {
            data.videos.forEach(video => {
                const videoItem = document.createElement('div');
                videoItem.className = 'video-item d-flex align-items-center gap-2 mb-2 p-2 border rounded bg-white';
                videoItem.innerHTML = `
                    <i class="bi bi-play-circle text-primary fs-5"></i>
                    <span class="flex-grow-1">${video}</span>
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteVideo('${video}')">
                        <i class="bi bi-trash"></i>
                    </button>
                `;
                videoList.appendChild(videoItem);
            });
        } else {
            videoList.innerHTML = `
                <div class="text-center py-4">
                    <i class="bi bi-film text-muted fs-1"></i>
                    <p class="text-muted mt-2 mb-0">ไม่พบวิดีโอ</p>
                    <small class="text-muted">กรุณาอัพโหลดวิดีโอที่ต้องการแสดง</small>
                </div>
            `;
        }
        
        // เพิ่ม log เพื่อดูข้อมูลที่ได้รับ
        console.log('Video data received:', data);
        
    } catch (error) {
        console.error('Error loading videos:', error);
        showAlert('error', 'ข้อผิดพลาด', 'ไม่สามารถโหลดรายการวิดีโอ���ด้');
    }
}
const style = document.createElement('style');
style.textContent = `
    .spin {
        animation: spin 1s linear infinite;
    }
    @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
`;
document.head.appendChild(style);
async function handleVideoUpload(event) {
    event.preventDefault(); // ป้องกันการ submit form
    
    const fileInput = document.getElementById('videoUpload');
    const file = fileInput.files[0];
    if (!file) {
        showAlert('warning', 'แจ้งเตือน', 'กรุณาเลือกไฟล์วิดีโอ');
        return;
    }

    // แสดง loading
    const uploadBtn = document.getElementById('uploadVideoBtn');
    const originalBtnText = uploadBtn.innerHTML;
    uploadBtn.disabled = true;
    uploadBtn.innerHTML = '<i class="bi bi-arrow-repeat spin"></i> กำลังอัพโหลด...';

    const formData = new FormData();
    formData.append('video', file);

    try {
        const response = await fetch('/api/videos/upload', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();
        if (result.success) {
            showAlert('success', 'อัพโหลดสำเร็จ', 'อัพโหลดวิดีโอเรียบร้อยแล้ว');
            await loadVideoList();
            fileInput.value = ''; // รีเซ็ต input
        } else {
            throw new Error(result.error);
        }
    } catch (error) {
        console.error('Error uploading video:', error);
        showAlert('error', 'ข้อผิดพลาด', 'ไม่สามารถอัพโหลดวิดีโอได้');
    } finally {
        // คืนค่าปุ่มกลับเป็นปกติ
        uploadBtn.disabled = false;
        uploadBtn.innerHTML = originalBtnText;
    }
}

async function deleteVideo(filename) {
    if (!confirm('ต้องการลบวิดีโอนี้ใช่หรือไม่?')) return;

    try {
        const response = await fetch(`/api/videos/${encodeURIComponent(filename)}`, {
            method: 'DELETE'
        });

        const result = await response.json();
        if (result.success) {
            showAlert('success', 'ลบสำเร็จ', 'ลบวิดีโอเรียบร้อยแล้ว');
            await loadVideoList();
        } else {
            throw new Error(result.error);
        }
    } catch (error) {
        console.error('Error deleting video:', error);
        showAlert('error', 'ข้อผิดพลาด', 'ไม่สามารถลบวิดีโอได้');
    }
}

// เรียกใช้ฟังก์ชันเมื่อโหลดน้า
document.addEventListener('DOMContentLoaded', () => {
    initVideoManagement();
});

// เพิ่มฟังก์ชันตรวจสอบรหัสผ่าน
async function verifyPassword(password) {
    try {
        const response = await fetch('/verify-password', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ password })
        });
        return await response.json();
    } catch (error) {
        console.error('Error verifying password:', error);
        return { success: false, error: 'ไม่สามารถตรวจสอบรหัสผ่านได้' };
    }
}

// แก้ไข Event Listeners
document.addEventListener('DOMContentLoaded', async () => {
    const passwordModal = new bootstrap.Modal(document.getElementById('passwordModal'));
    passwordModal.show();

    // จัดการการส่งฟอร์มรหัสผ่าน
    document.getElementById('passwordForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const password = document.getElementById('passwordInput').value;
        const result = await verifyPassword(password);

        if (result.success) {
            passwordModal.hide();
            // โหลดการตั้งค่าต่างๆ
            socket.emit('getPorts');
            socket.emit('getPortConfig');
            socket.emit('getDbSettings');
            socket.emit('getColorConfig');
            loadStaffSettings();
        } else {
            showAlert('error', 'รหัสผ่านไม่ถูกต้อง', 'กรุณาลองใหม่อีกครั้ง');
            document.getElementById('passwordInput').value = '';
        }
    });

    // จัดการปุ่มยกเลิก
    document.getElementById('cancelPassword').addEventListener('click', () => {
        window.location.href = '/';
    });
});


