document.addEventListener('DOMContentLoaded', async () => {
    const socket = io();
    
    try {
        // อ่านข้อมูลจากทั้ง localStorage และ readings.json
        const patientFromStorage = JSON.parse(localStorage.getItem('currentPatient') || '{}');
        
        // อ่านข้อมูลจาก readings.json
        const response = await fetch('/data/readings.json');
        const readingsData = await response.json();
        
        // รวมข้อมูลจากทั้งสองแหล่ง
        const patient = {
            patientInfo: patientFromStorage,
            readings: readingsData.readings
        };

        console.log('=== สรุปข้อมูลการวัดทั้งหมด ===', patient);
        
        if (patient.patientInfo?.hn && patient.patientInfo?.vn) {
            const vitalSigns = {
                hn: patient.patientInfo.hn,
                vn: patient.patientInfo.vn,
                temperature: patient.readings?.temperature,
                systolic: patient.readings?.pressure?.systolic,
                diastolic: patient.readings?.pressure?.diastolic,
                pulse: patient.readings?.pressure?.pulse,
                weight: patient.readings?.bmi?.weight,
                height: patient.readings?.bmi?.height
            };

            // บันทึกข้อมูล vital signs
            const saveResult = await new Promise((resolve, reject) => {
                socket.emit('saveVitalSigns', vitalSigns, (response) => {
                    if (response.success) {
                        resolve(response);
                    } else {
                        reject(new Error(response.message));
                    }
                });
            });
            
            console.log('บันทึกข้อมูลสำเร็จ:', vitalSigns);
            
            // รีเซ็ตข้อมูล
            try {
                await new Promise((resolve, reject) => {
                    socket.emit('resetReadings', (response) => {
                        if (response && response.success) {
                            console.log('รีเซ็ตข้อมูลสำเร็จ');
                            resolve();
                        } else {
                            reject(new Error('ไม่สามารถรีเซ็ตข้อมูลได้'));
                        }
                    });
                });
            } catch (error) {
                console.error('เกิดข้อผิดพลาดในการรีเซ็ตข้อมูล:', error.message);
            }

            // ลบข้อมูลใน localStorage
            localStorage.removeItem('currentPatient');
            
            // เริ่มนับถอยหลัง
            let timeLeft = 3;
            const timerElement = document.getElementById('timer');
            const countdownElement = document.querySelector('.countdown');

            if (timerElement && countdownElement) {
                // รอให้ animation ของ countdown element ทำงานเสร็จ (1.5 วินาที)
                setTimeout(() => {
                    // ตั้งค่าเริ่มต้น
                    timerElement.textContent = timeLeft;
                    
                    const countdown = setInterval(() => {
                        timeLeft--;
                        timerElement.textContent = timeLeft;
                        
                        if (timeLeft <= 0) {
                            clearInterval(countdown);
                            document.querySelector('.thank-you-container').style.animation = 'fadeIn 1s reverse';
                            setTimeout(() => {
                                window.location.href = '/';
                            }, 800);
                        }
                    }, 1000);
                }, 1500); // รอให้ animation เสร็จสิ้น (1 วินาที delay + 0.5 วินาทีสำหรับ animation)
            } else {
                console.error('ไม่พบ element ที่จำเป็น');
                setTimeout(() => {
                    window.location.href = '/';
                }, 5000);
            }

        } else {
            console.log('ไม่พบข้อมูลผู้ป่วย');
            setTimeout(() => {
                window.location.href = '/';
            }, 3000);
        }

    } catch (error) {
        console.error('เกิดข้อผิดพลาดในการบันทึกข้อมูล:', error.message);
        setTimeout(() => {
            window.location.href = '/';
        }, 3000);
    }
});
