const socket = io();

// เพิ่มตัวแปรสำหรับป้องกันการสแกนซ้ำ
let isProcessing = false;
let lastSearchValue = '';
let debounceTimer = null;

// เพิ่มฟังก์ชันสำหรับ focus input และล้างค่า
function focusSearchInput() {
    const searchInput = document.getElementById('searchValue');
    searchInput.value = ''; // ล้างค่าเก่า
    searchInput.focus(); // focus ที่ช่อง input
    isProcessing = false; // รีเซ็ตสถานะ
    lastSearchValue = ''; // รีเซ็ตค่าที่ค้นหาล่าสุด
}

// เรียกใช้ฟังก์ชันเมื่อโหลดหน้า
document.addEventListener('DOMContentLoaded', focusSearchInput);

// เพิ่ม event listener สำหรับการกด ESC เพื่อล้างค่าและ focus ใหม่
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        focusSearchInput();
    }
});

// ฟังก์ชันสำหรับการค้นหา
function searchPatient(searchValue) {
    // ตรวจสอบว่าค่าไม่ซ้ำกับการค้นหาล่าสุด
    if (searchValue === lastSearchValue || isProcessing) {
        console.log('ป้องกันการค้นหาซ้ำ:', searchValue);
        return;
    }

    isProcessing = true;
    lastSearchValue = searchValue;

    // ส่งค่าไปค้นหา
    socket.emit('searchPatients', searchValue);

    // ตั้งเวลารีเซ็ตสถานะหลังจาก 1 วินาที
    setTimeout(() => {
        isProcessing = false;
    }, 1000);
}

// เพิ่ม event listener สำหรับเมื่อเสียบบัตร
socket.on('cardInserted', (data) => {
    const searchInput = document.getElementById('searchValue');
    searchInput.value = data.cid;
    searchPatient(data.cid);
});

// เพิ่ม event listener สำหรับการเปลี่ยนแปลงค่าใน input
document.getElementById('searchValue').addEventListener('input', function(e) {
    const searchValue = e.target.value.trim();
    
    // ยกเลิก timer เดิม (ถ้ามี)
    if (debounceTimer) {
        clearTimeout(debounceTimer);
    }
    
    // ตรวจสอบความยาวของข้อมูล
    if (searchValue.length >= 6) {
        debounceTimer = setTimeout(() => {
            searchPatient(searchValue);
        }, 100);
    }
});

// ปรับปรุง form submit event
document.getElementById('searchForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const searchValue = document.getElementById('searchValue').value.trim();
    
    if (!searchValue) {
        alert('กรุณาระบุคำค้นหา');
        return;
    }
    
    searchPatient(searchValue);
});

// เพิ่ม event listener สำหรับผลการค้นหา
socket.on('patientFound', (patient) => {
    displayPatient(patient);
    // รีเซ็ตสถานะหลังแสดงผล
    setTimeout(() => {
        focusSearchInput();
    }, 500);
});

socket.on('patientNotFound', (message) => {
    const tbody = document.getElementById('patientList');
    tbody.innerHTML = `
        <tr>
            <td colspan="7" class="text-center">${message}</td>
        </tr>
    `;
    // รีเซ็ตสถานะหลังแสดงผล
    setTimeout(() => {
        focusSearchInput();
    }, 500);
});

// ฟังก์ชันแสดงข้อมูลคนไข้
function displayPatient(patient) {
    const tbody = document.getElementById('patientList');
    tbody.innerHTML = '';
    
    if (!patient) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="text-center">ไม่พบข้อมูล</td>
            </tr>
        `;
        return;
    }
    
    // แปลงรูปแบบวันที่
    const birthDate = new Date(patient.thai_birthday);
    const thaiDate = birthDate.toLocaleDateString('th-TH', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
        
    const row = document.createElement('tr');
    row.innerHTML = `
        <td>${patient.hn || '-'}</td>
        <td>${patient.vn || '-'}</td>
        <td>${patient.cid || '-'}</td>
        <td>${patient.patient_name || '-'}</td>
        <td>${patient.age || '-'}</td>
        <td>${thaiDate || '-'}</td>
        <td>
            <button class="btn btn-sm btn-primary" onclick="viewPatient('${patient.hn}')">
                ดูข้อมูล
            </button>
        </td>
    `;
    tbody.appendChild(row);
}

// รับข้อมูลคนไข้จาก server
socket.on('patientFound', (patient) => {
    displayPatient(patient);
});

socket.on('patientNotFound', (message) => {
    const tbody = document.getElementById('patientList');
    tbody.innerHTML = `
        <tr>
            <td colspan="7" class="text-center">${message}</td>
        </tr>
    `;
});

socket.on('searchError', (error) => {
    alert('เกิดข้อผิดพลาด: ' + error);
});

// ฟังก์ชันดูข้อมูลคนไข้
function viewPatient(hn) {
    window.location.href = `/patient/${hn}`;
} 