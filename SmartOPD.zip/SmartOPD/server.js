const express = require('express');
const { SerialPort } = require('serialport');
const app = express();
const http = require('http').Server(app);
const io = require('socket.io')(http);
const pools = require('./db/db.js');
const mysql = require('mysql2/promise');
const fs = require('fs');
const fsPromises = require('fs').promises;
const path = require('path');
const { ReadlineParser } = require('@serialport/parser-readline');
const { autoDetect } = require('@serialport/bindings-cpp');
const Binding = autoDetect();
const { Devices } = require('smartcard');
const devices = new Devices();
const iconv = require('iconv-lite');
const multer = require('multer');
const os = require('os');
const util = require('util');
const HID = require('node-hid');
const readdir = util.promisify(fs.readdir);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// เพิ่มบรรทัดนี้หลังจาก const app = express();
app.use(express.static('public'));
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads')));
// Utility function สำหรับ delay
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

// Utility function สำหรับ retry
async function retry(fn, retries = 3, delay_ms = 1000) {
    for (let i = 0; i < retries; i++) {
        try {
            return await fn();
        } catch (error) {
            if (i === retries - 1) throw error;
            console.log(`พยายาอีกครั้ง... (${i + 1}/${retries})`);
            await delay(delay_ms);
        }
    }
}
async function testConnection() {
    try {
        const connection = await pools.primary.getConnection();
        console.log('Database connected successfully');
        connection.release();
    } catch (err) {
        console.error('Error connecting to database:', err);
    }
}
// ทดอบการเชื่อมต่อฐานข้อมูล
(async () => {
    try {
        testConnection();
    } catch (error) {
        console.error('Error connecting to database:', error);
    }
})();

// ตั้งค่า EJS
app.set('view engine', 'ejs');
app.set('views', './views');
app.use(express.static('public'));
// เพิ่มที่จุดเริ่มต้นของแอพ
const videosDir = path.join(__dirname, 'public', 'videos');
if (!fs.existsSync(videosDir)) {
    fs.mkdirSync(videosDir, { recursive: true });
    console.log('Created videos directory:', videosDir);
}

// เพิ่ม middleware สำหรับเข้าถึงไฟล์วิดีโอ
app.use('/videos', express.static(path.join(__dirname, 'public', 'videos')));
// ประกาศตัวแปร global ทั้งหมดตรงนี้
let pressurePort = null;
let tempPort = null;
let weightPort = null;

// ประกาศตัวแปร lastReadings
let lastReadings = {
    systolic: null,
    diastolic: null,
    pulse: null,
    temperature: null,
    weight: null,  // เพิ่มสำหรับน้ำหนัก
    height: null   // เพิ่มสำหรับส่วนสูง
};

// ตัวแปรสำหรับจัดการการเชื่อมต่อซ้ำ
let reconnectAttempts = {
    pressure: 0,
    temp: 0,
    weight: 0
};

let reconnectIntervals = {
    pressure: null,
    temp: null,
    weight: null
};

// ตัวแปรสำหรับ retry timer
let reconnectTimers = {
    pressure: null,
    temp: null,
    weight: null
};

// เพิ่มตัวปรสำหรับจัดการการเชื่อมต่อซ้ำ
const MAX_RECONNECT_ATTEMPTS = 3;
const RECONNECT_DELAY = 5000; // 5 วินาที

// เิิมตัวแป���สหรับจัดการการเชื่อมต่อซ้ำ


// เพิ่มตัวแปรสำหรับจัดการ card reader
let cardReader = null;
let cardConnection = null;
function setupWeightPortReader(port) {
    console.log('=== Weight Port Setup ===');
    console.log('Port path:', port.path);
    
    const parser = port.pipe(new ReadlineParser({ 
        delimiter: '\r\n',
        encoding: 'utf8'
    }));

    parser.on('data', (line) => {
        try {
            console.log('\n=== Parsed Weight Line ===');
            console.log('Line:', line);

            // แยกข้อมูลน้ำหนักและส่วนสูง
            const weightMatch = line.match(/W:(\d+\.?\d*)/);
            const heightMatch = line.match(/H:(\d+\.?\d*)/);

            if (weightMatch || heightMatch) {
                const data = {
                    weight: weightMatch ? weightMatch[1] : null,  // ไม่ต้อง parseFloat ที่นี่
                    height: heightMatch ? heightMatch[1] : null   // ไม่ต้อง parseFloat ที่นี่
                };

                console.log('Emitting weight_height data:', data);
                io.emit('weight_height', data);
            }
        } catch (error) {
            console.error('Error parsing weight/height data:', error);
        }
    });

    // จัดการ errors
    parser.on('error', (err) => {
        console.error('Weight parser error:', err);
    });

    port.on('error', (err) => {
        console.error('Weight port error:', err);
        handlePortDisconnection('weight');
    });

    port.on('close', () => {
        console.log('Weight port closed');
        handlePortDisconnection('weight');
    });
}
async function disconnectAllPorts() {
    try {
        // ยกเลิกการเชื่อมต่อทุกพอร์ต
        const portTypes = ['pressure', 'temp', 'weight'];
        
        for (const type of portTypes) {
            // ยกเลิก timer reconnect ถ้ามี
            if (reconnectTimers[type]) {
                clearTimeout(reconnectTimers[type]);
                reconnectTimers[type] = null;
            }
            
            // เลือกพอร์ตตามประเภท
            let port;
            switch(type) {
                case 'pressure':
                    port = pressurePort;
                    break;
                case 'temp':
                    port = tempPort;
                    break;
                case 'weight':
                    port = weightPort;
                    break;
            }

            // ปิดการเชื่อมต่อถ้าพอร์ตเปิดอยู่
            if (port && port.isOpen) {
                await new Promise((resolve) => port.close(resolve));
            }

            // รีเซ็ตตัวแปรพอร์ต
            switch(type) {
                case 'pressure':
                    pressurePort = null;
                    break;
                case 'temp':
                    tempPort = null;
                    break;
                case 'weight':
                    weightPort = null;
                    break;
            }

            // อัพเดทสถานะการเชื่อมต่อ
            connectionStatus[type] = { connected: false, connecting: false };
        }

        // อัพเดท portConfig
        const config = JSON.parse(fs.readFileSync('config/portConfig.json', 'utf8'));
        for (const type of portTypes) {
            if (config.ports[type]) {
                config.ports[type].enabled = false;
            }
        }
        fs.writeFileSync('config/portConfig.json', JSON.stringify(config, null, 4));

        // แจ้งเตือนการอัพเดทสถานะ
        io.emit('connectionStatus', connectionStatus);
        
        return true;
    } catch (error) {
        console.error('Error disconnecting all ports:', error);
        return false;
    }
}
// เพิ่มฟังก์ชัน createPort
function createPort(portPath, type) {
    try {
        const config = {
            path: portPath,
            baudRate: type === 'temp' ? 115200 : 9600,
            dataBits: 8,
            stopBits: 1,
            parity: 'none'
        };

        const port = new SerialPort(config);
        setupPortListeners(port, type);
        return port;
    } catch (error) {
        console.error(`Error creating ${type} port:`, error);
        return null;
    }
}

// อัพเดทฟังก์ชั connectPort
async function connectPort(portPath, type, baudRate) {
    try {
        // ยกเลิก timer reconnect (ถ้าม��)
        if (reconnectTimers[type]) {
            clearTimeout(reconnectTimers[type]);
            reconnectTimers[type] = null;
        }

        if (connectionStatus[type]?.connecting) {
            return false;
        }

        console.log(`Attempting to connect ${type} port: ${portPath} with baud rate: ${baudRate}`);
        connectionStatus[type] = { connected: false, connecting: true };
        
        const port = new SerialPort({
            path: portPath,
            baudRate: baudRate || (type === 'temp' ? 115200 : 9600), // default baudRate ตามประเภท
            dataBits: 8,
            stopBits: 1,
            parity: 'none',
            autoOpen: false
        });

        await new Promise((resolve, reject) => {
            port.open((err) => {
                if (err) {
                    reject(err);
                } else {
                    resolve();
                }
            });
        });

        if (type === 'pressure') {
            pressurePort = port;
            setupPressurePortReader(port);
        } else if (type === 'temp') {
            tempPort = port;
            setupTempPortReader(port);
        } else if (type === 'weight') {
            weightPort = port;
            setupWeightPortReader(port); // ต้องสร้างฟังก์ชันน���้เพิ่ม
        }

        // อัพเดท portConfig เมื่อเชื่อมต่อสำเร็จ
        const config = JSON.parse(fs.readFileSync('config/portConfig.json', 'utf8'));
        if (!config.ports[type]) config.ports[type] = {};
        config.ports[type] = {
            ...config.ports[type],
            path: portPath,
            baudRate: baudRate,
            enabled: true
        };
        fs.writeFileSync('config/portConfig.json', JSON.stringify(config, null, 4));

        connectionStatus[type] = {
            connected: true,
            connecting: false,
            port: portPath,
            baudRate: baudRate
        };

        setupPortListeners(port, type);
        io.emit('connectionStatus', connectionStatus);
        io.emit('portSuccess', {
            type: type,
            message: `เชื่อมต่อพอร์ต ${type} สำเร็จ`
        });

        return true;
    } catch (error) {
        console.error(`Error connecting ${type} port:`, error);
        connectionStatus[type] = { connected: false, connecting: false };
        io.emit('portError', {
            type: type,
            code: `ERR_${type.toUpperCase()}_CONNECTION_FAILED`,
            message: `ไม่สามารถเชื่อมต่อพอร์ต ${type}: ${error.message}`
        });
        return false;
    }
}

// เพิ่มตัวแปรเก็บสถานะการเชื่อมต่อ
let connectionStatus = {
    pressure: {
        connected: false,
        port: ''
    },
    temp: {
        connected: false,
        port: ''
    },
    weight: {
        connected: false,
        port: ''
    }
};

// อั��เดฟังชัน connectPorts
async function connectPorts() {
    try {
        const configPath = path.join(__dirname, 'config', 'portConfig.json');
        const config = JSON.parse(await fsPromises.readFile(configPath, 'utf8'));

        // เชื่อมต่อเครื่องวัดความดัน
        if (config.ports.pressure?.enabled) {
            pressurePort = await connectPort({
                path: config.ports.pressure.path,
                baudRate: config.ports.pressure.baudRate || 2400,
                type: 'pressure'
            });
        }

        // เชื่อมต่อเครื่องวัดอุณหภูมิ
        if (config.ports.temp?.enabled) {
            tempPort = await connectPort({
                path: config.ports.temp.path,
                baudRate: 115200,  // กำหนดค่าตายตัว
                type: 'temp'
            });
        }

        // เชื่อมต่อเครื่องชั่ง
        if (config.ports.weight?.enabled) {
            weightPort = await connectPort({
                path: config.ports.weight.path,
                baudRate: config.ports.weight.baudRate || 9600,
                type: 'weight'
            });
        }

    } catch (error) {
        console.error('Error connecting ports:', error);
    }
}

// config สำหร database
let dbConfig = JSON.parse(fs.readFileSync('config/dbConfig.json', 'utf8'));

// เพิ่ม event handlers
io.on('connection', async (socket) => {
    console.log('Client connected');

    // แจ้งเตือนทุก client ที่เชื่อมต่อใหม่ว่าเซิฟเวอร์พร้อมใช้งาน
    socket.emit('serverReady', {
        success: true,
        message: 'เซิฟเวอร์พร้อมใช้งานแล้ว'
    });

    // ส่งสถานะปัจจุบนไปยัง client ที่เพิ่งเชื่อมต่อ
    socket.emit('connectionStatus', connectionStatus);

    // Event handlers สำหรับพอร์ต
    socket.on('getPorts', async () => {
        try {
            const ports = await SerialPort.list();
            socket.emit('portList', ports);
        } catch (error) {
            console.error('Error listing ports:', error);
            socket.emit('error', 'ไม่สามารถดึงรายการพอร์ตได้');
        }
    });

    socket.on('togglePort', async ({ type, port, baudRate, action }) => {
        try {
            console.log(`Attempting to ${action} ${type} port:`, port);
            
            if (action === 'connect') {
                const success = await connectPort(port, type, baudRate);
                if (!success) {
                    throw new Error(`ไม่สามารถเชื่อมต่อพอร์ต ${type} ได้`);
                }
            } else {
                const success = await disconnectPort(type);
                if (!success) {
                    throw new Error(`ไม่สามารถยกเลิกการเชื่อม��่อพอร์ต ${type} ได้`);
                }
            }
            socket.emit('connectionStatus', connectionStatus);
        } catch (error) {
            console.error(`Error ${action}ing ${type} port:`, error);
            socket.emit('error', error.message);
        }
    });

    // Event handlers สำหรั��การตั้งค่ฐานข้อมูล
    socket.on('getDbSettings', () => {
        try {
            const configPath = path.join(__dirname, 'config', 'dbConfig.json');
            const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
            socket.emit('dbSettings', config);
        } catch (error) {
            console.error('Error reading db config:', error);
            // ส่ง����่าเริ�����ต้นถ้าไม่มีไฟล
            const defaultConfig = {
                host: 'localhost',
                user: 'root',
                password: '',
                primaryDatabase: 'hos',
                secondaryDatabase: '',
                useSecondaryDb: false
            };
            socket.emit('dbSettings', defaultConfig);
        }
    });

    socket.on('saveDbSettings', async (settings) => {
        try {
            // บันทึกการตั้งค่าลงไฟล์
            await fsPromises.writeFile(
                path.join(__dirname, 'config', 'dbConfig.json'),
                JSON.stringify(settings, null, 4)
            );

            socket.emit('dbSettingsSaved', {
                success: true,
                message: 'บันทึกการตั้งค่าเรียบร้อยแล้ว'
            });

            // แจ้งเตือนว่ากำลังจะรีสตาร์ท
            io.emit('serverRestarting', {
                message: 'กำลังรีสตาร์ทเซิร์ฟเวอร์เพื่อใช้งานการตั้งค่าใหม่'
            });

            // รอสักครู่แล้วค่อยรีสตาร์ท
            setTimeout(() => {
                process.exit(100); // รหัส 100 สำหรับการรีสตาร์ท
            }, 1000);

        } catch (error) {
            console.error('Error saving db settings:', error);
            socket.emit('dbSettingsSaved', {
                success: false,
                error: error.message
            });
        }
    });

    let currentSession = {
        patientInfo: null,
        readings: {
            temperature: null,
            pressure: {
                systolic: null,
                diastolic: null,
                pulse: null
            },
            bmi: {
                weight: null,
                height: null
            }
        }
    };

    socket.on('updateReadings', async (data) => {
        try {
            // อ่านข้อมูลเดิมจากไฟล์ (ถ้ามี)
            try {
                const existingData = await fsPromises.readFile(
                    path.join(__dirname, 'data', 'readings.json'),
                    'utf8'
                );
                globalReadings = JSON.parse(existingData);
            } catch (error) {
                console.log('ไม่พบข้อมูลเดิม หรือเป็นการวั���ครั้งแรก');
            }

            // อัพเดทข้อมูลใหม่
            if (data.type === 'temperature') {
                globalReadings.readings.temperature = data.value;
            } else if (data.type === 'pressure') {
                globalReadings.readings.pressure = data.value;
            } else if (data.type === 'bmi') {
                globalReadings.readings.bmi = data.value;
            } else if (data.type === 'patient') {
                globalReadings.patientInfo = data.value;
            }

            // บันทึกลงไฟล์ JSON
            await fsPromises.writeFile(
                path.join(__dirname, 'data', 'readings.json'),
                JSON.stringify(globalReadings, null, 2)
            );

            console.log('บันทึกข้อมูลปัจจุบัน:', globalReadings);


        } catch (error) {
            console.error('Error updating readings:', error);
        }
    });

    socket.on('disconnect', () => {
        console.log('Client disconnected');
    });

    socket.on('getConnectionStatus', () => {
        const status = checkPortStatus();
        socket.emit('connectionStatus', status);
    });

    // ส่งค่า config ให้ client
    socket.on('getPortConfig', async () => {
        const config = await readPortConfig();
        socket.emit('portConfig', config);
    });

    // รับค่า config จาก client และบันทึก
    socket.on('savePortConfig', async ({ type, config }) => {
        const currentConfig = await readPortConfig();
        currentConfig.ports = currentConfig.ports || {};
        currentConfig.ports[type] = config;
        await savePortConfig(currentConfig);
    });

    // เพิ่มการตรวจจับการหลุดของพอร์ต
    if (pressurePort) {
        pressurePort.on('close', () => {
            console.log('Pressure port disconnected');
            io.emit('connectionStatus', checkPortStatus());
        });
    }

    if (tempPort) {
        tempPort.on('close', () => {
            console.log('Temperature port disconnected');
            io.emit('connectionStatus', checkPortStatus());
        });
    }

    // เพิ่ม event สำหรบขอสถานะ card reader
    socket.on('getCardReaderStatus', () => {
        socket.emit('cardReaderStatus', {
            hasReader: cardReader !== null,
            readerName: cardReader?.name || null,
            hasCard: cardConnection !== null
        });
    });

    // เพิ่ม event handlers สำหรับก��รคนหาคนไข้
    socket.on('searchPatients', async (searchValue) => {
        try {
            const connection = await pools.primary.getConnection();
            
            // แก้ไข query ให้ใช้ตารา�� vn_stat
            const query = `
                SELECT DISTINCT
                    p.hn,
                    vs.vn,
                    p.cid,
                    CONCAT(p.fname, ' ', p.lname) as patient_name,
                    TIMESTAMPDIFF(YEAR, p.birthday, CURDATE()) as age,
                    DATE_FORMAT(p.birthday, '%d %M %Y') as thai_birthday
                FROM patient p
                LEFT JOIN vn_stat vs ON p.hn = vs.hn
                WHERE 
                    p.hn = ? OR 
                    p.cid = ? OR 
                    vs.vn = ?
                ORDER BY vs.vn DESC
                LIMIT 1
            `;
            
            console.log('Searching with value:', searchValue);
            
            const [rows] = await connection.execute(query, [
                searchValue, // ค้นหาจาก HN
                searchValue, // ค้นหาจาก CID
                searchValue  // ค้นหาจาก VN
            ]);
            
            connection.release();

            if (rows.length > 0) {
                currentPatient = rows[0];
                console.log('Found patient:', currentPatient);
                socket.emit('patientFound', currentPatient);
            } else {
                currentPatient = null;
                console.log('Patient not found');
                socket.emit('patientNotFound', 'ไม่พบข้อมูลผู้ป่วย');
            }
            
        } catch (error) {
            console.error('Error searching patients:', error);
            socket.emit('searchError', 'เกิดข้อผิดพลาดในการค้นหาข้อมูล');
        }
    });

    socket.on('getColorSettings', async () => {
        const config = await readColorConfig();
        console.log('Sending color settings to client:', config);
        socket.emit('colorSettings', config);
    });

    socket.on('saveColorSettings', async (settings) => {
        const success = await saveColorConfig(settings);
        socket.emit('colorSettingsSaved', { success });
    });

    // แก้ไขฟังก์ชันที่รับค่าจากเครื่องวัด
    socket.on('savePressure', async (data) => {
        try {
            await saveVitalSigns({
                ...data,
                temperature: lastReadings.temperature,
                hn: currentPatient?.hn,
                vn: currentPatient?.vn
            });
            
            // เคลียร์ค่าหลังจากบันทึก
            lastReadings = {
                systolic: null,
                diastolic: null,
                pulse: null,
                temperature: lastReadings.temperature // เก็บ่าอุณหภูมิไว้
            };
            
            // ส่งค่าที่เคลียร์ไว้กลับไปที่ client
            io.emit('pressure', {
                systolic: '-',
                diastolic: '-',
                pulse: '-'
            });
            
        } catch (error) {
            io.emit('dataSaved', { 
                success: false,
                message: 'เกิดข้อผิดพลาดในการบันทึกข้อมูล'
            });
        }
    });



    // เพิ่ม event handler สำหรับการเชื่อมต่อใหม่
    socket.on('connect', () => {
        // เคลียร์ค่าเมื่อมีการเชื���อมต่อใหม่
        lastReadings = {
            systolic: null,
            diastolic: null,
            pulse: null,
            temperature: null
        };
        currentPatient = null;
    });

    // ส่งการตั้งค่า staff
    socket.on('getStaffSettings', async () => {
        try {
            console.log('Getting staff settings');
            const config = await readStaffConfig();
            console.log('Staff config:', config);
            socket.emit('staffSettings', config);
        } catch (error) {
            console.error('Error reading staff settings:', error);
            socket.emit('staffSettings', { staffName: '' });
        }
    });

    // บันทึกการตั้งค่า staff
    socket.on('saveStaffSettings', async (settings) => {
        try {
            console.log('Saving staff settings:', settings);
            
            if (!settings.staffName) {
                throw new Error('กรุณากรอกชื่อเจ้าหน้าที่');
            }

            const success = await saveStaffConfig(settings);
            console.log('Save result:', success);
            
            socket.emit('staffSettingsSaved', {
                success: true,
                message: 'บันทึกชื่อเจ้าหน้าที่สำเร็จ'
            });

        } catch (error) {
            console.error('Error saving staff settings:', error);
            socket.emit('staffSettingsSaved', {
                success: false,
                error: error.message
            });
        }
    });

    socket.on('testDbConnection', async (settings) => {
        try {
            // ทดสอบการเชื่อมต่อฐานข้อมูลหลัก
            const primaryConnection = await mysql.createConnection({
                host: settings.host,
                user: settings.user,
                password: settings.password,
                database: settings.primaryDatabase
            });
            await primaryConnection.end();

            // ทดสอบการเชื่อมต่อฐานข้อมูลรอง (ถ้ามี)
            if (settings.useSecondaryDb) {
                const secondaryConnection = await mysql.createConnection({
                    host: settings.host,
                    user: settings.user,
                    password: settings.password,
                    database: settings.secondaryDatabase
                });
                await secondaryConnection.end();
            }

            socket.emit('dbTestResult', { success: true });
        } catch (error) {
            socket.emit('dbTestResult', { 
                success: false, 
                error: error.message 
            });
        }
    });

    socket.on('reconnectDatabase', async () => {
        try {
            // ปิดกรรเชื่อม่อเดิม
            if (pools.primary) {
                await pools.primary.end();
            }
            if (pools.secondary) {
                await pools.secondary.end();
            }

            // สร้างการเชื่อมต่อใหม่
            await initializeDatabasePools();
            
            socket.emit('databaseReconnected', { 
                success: true,
                message: 'เชื่อมต่อฐานข้อมูลใหม่สำเร็จ'
            });
        } catch (error) {
            socket.emit('databaseReconnected', { 
                success: false,
                error: error.message
            });
        }
    });

    socket.on('disconnectAllPorts', async () => {
        await disconnectAllPorts();
        socket.emit('portsDisconnected');
    });

    socket.on('savePortConfig', async (data) => {
        try {
            const configPath = path.join(__dirname, 'config', 'portConfig.json');
            let config = {};
            
            // อ่านไฟล์ config เดิม (ถ้ามี)
            try {
                config = JSON.parse(await fs.promises.readFile(configPath, 'utf8'));
            } catch (err) {
                config = { ports: {} };
            }

            // อัพเดทค่า config
            if (!config.ports) config.ports = {};
            if (!config.ports[data.type]) config.ports[data.type] = {};
            
            config.ports[data.type] = {
                ...config.ports[data.type],
                ...data.config,
                enabled: true
            };

            // บันท���กไฟล์ config
            await fs.promises.writeFile(configPath, JSON.stringify(config, null, 4));
            
            socket.emit('portConfigSaved', { success: true });
        } catch (error) {
            console.error('Error saving port config:', error);
            socket.emit('portConfigSaved', { 
                success: false, 
                error: error.message 
            });
        }
    });

    // ส่ง display config เมื่อเชื่อมต่อ
    const config = await getDisplayConfig();
    socket.emit('displayConfig', config);

    // รับคำสังบันทึก config
    socket.on('saveDisplayConfig', async (config, callback) => {
        try {
            // ตรวจสอบว่ามี�����่างน้อย 1 หน้าที่เปิดใช้งาน
            const enabledPages = Object.values(config.enabled).filter(enabled => enabled);
            if (enabledPages.length === 0) {
                if (typeof callback === 'function') {
                    callback({ success: false, error: 'ต้องเปิดใช้งานอย่างน้อย 1 หน้า' });
                }
                return;
            }

            // บันทึกการตั้งค่า
            await fsPromises.writeFile(
                displayConfigPath,
                JSON.stringify(config, null, 4)
            );

            // ส่งการตั้งค่าใหม่ให้ทุก client
            io.emit('displayConfigUpdated', config);
            
            // เรียก callback ถ้ามี
            if (typeof callback === 'function') {
                callback({ success: true });
            }
        } catch (error) {
            console.error('Error saving display config:', error);
            if (typeof callback === 'function') {
                callback({ success: false, error: error.message });
            }
        }
    });

    socket.on('getDisplayConfig', async (callback) => {
        try {
            const config = await validateDisplayConfig();
            callback(config);
        } catch (error) {
            console.error('Error getting display config:', error);
            callback(null);
        }
    });

    // เพิ่มตัวแปรเก็บข้อมูลการวัดชั่วคราว
    let tempReadings = {
        patientInfo: {
            hn: null,
            vn: null,
            patientName: null
        },
        temperature: null,
        pressure: {
            systolic: null,
            diastolic: null,
            pulse: null
        },
        bmi: {
            weight: null,
            height: null
        }
    };

    // รีเซ็ตข้อมูล
    socket.on('resetReadings', async (callback) => {
        try {
            globalReadings = {
                patientInfo: null,
                readings: {
                    temperature: null,
                    pressure: {
                        systolic: null,
                        diastolic: null,
                        pulse: null
                    },
                    bmi: {
                        weight: null,
                        height: null
                    }
                }
            };
            
            // บันทึกข้อมูลที่รีเซ็ตลงไฟล์
            await fsPromises.writeFile(
                path.join(__dirname, 'data', 'readings.json'),
                JSON.stringify(globalReadings, null, 2)
            );
            console.log('รีเซ็ตข้อมูลสำเร็จ');
            
            // ส่ง response กลับไปยัง client
            if (callback) callback({ success: true });
        } catch (error) {
            console.error('เกิดข้อผิดพลาดในการรีเซ็ตข้อมูล:', error);
            if (callback) callback({ success: false, error: error.message });
        }
    });

    // ดึงข้อมูลปัจจุบัน
    socket.on('getCurrentReadings', (data, callback) => {
        if (typeof callback === 'function') {
            callback(tempReadings);
        }
    });

    // แกไขการจัดการ socket สำหรบส่ง config
    io.on('connection', async (socket) => {
        // เม็บ tempReadings ไว้ใน socket session
        if (!socket.tempReadings) {
            socket.tempReadings = {
                patientInfo: {
                    hn: null,
                    vn: null,
                    patientName: null
                },
                temperature: null,
                pressure: {
                    systolic: null,
                    diastolic: null,
                    pulse: null
                },
                bmi: {
                    weight: null,
                    height: null
                }
            };
        }

        socket.on('saveMeasurement', async (data) => {
            try {
                // อัพเดทข้อมูลใน socket session
                if (data.type === 'patient') {
                    socket.tempReadings.patientInfo = {
                        hn: data.value.hn,
                        vn: data.value.vn,
                        patientName: data.value.patientName
                    };
                }
                
                // บันทึกอุณหภูมิ
                else if (data.type === 'temperature') {
                    socket.tempReadings.temperature = data.value;
                }
                
                // บันทึกความดัน
                else if (data.type === 'pressure') {
                    socket.tempReadings.pressure = data.value;
                }
                
                // บันทึก BMI
                else if (data.type === 'bmi') {
                    socket.tempReadings.bmi = data.value;
                }

                // บันทึกลง JSON file
                await fsPromises.writeFile(
                    path.join(__dirname, 'data', 'readings.json'),
                    JSON.stringify(socket.tempReadings, null, 2)
                );

                // ส่งการตั้งค่าให���่ไปยังทุก client
                io.emit('dataSaved', {
                    success: true,
                    message: 'บันทึกข้อมูลสำเร็จ'
                });

            } catch (error) {
                console.error('Error saving measurements:', error);
                socket.emit('dataSaved', {
                    success: false,
                    message: 'เกิดข้อผิดพลาดในการบันทึกข้อมูล: ' + error.message
                });
            }
        });

        socket.on('getAllTempReadings', (callback) => {
            callback(socket.tempReadings);
        });
    });

    // ส่งการตั้งค่าให้ client เมื่อมีการเชื่อมต่อ
    socket.emit('welcomeSettings', global.welcomeSettings || {
        hospitalName: 'โรงพยาบาลกรุงเทพ',
        welcomeImage: '/images/1.webp'
    });

    // รับการอัพเดทการตั้งค่าและส่งต่อไปยัง clients ท���้งหมด
    socket.on('welcomeSettingsUpdated', (settings) => {
        global.welcomeSettings = settings;
        io.emit('welcomeSettings', settings);
    });

    socket.on('getServerIP', () => {
        socket.emit('serverIP', getServerIP());
    });

    // เพิ่มฟังก์ชันสำหรับอ่านค่าเครื่องชั่ง
    socket.on('setupWeightPortReader', async (port) => {
        try {
            setupWeightPortReader(port);
        } catch (error) {
            console.error('Error setting up weight port:', error);
            socket.emit('error', 'เกิดข้อผิดพลาดในการตั้งค่าเครื่องชั่ง: ' + error.message);
        }
    });


    // แก้ไขการส่งสถานะการเชื่อมต่อ
    function updateConnectionStatus() {
        const status = {
            pressure: {
                connected: pressurePort?.isOpen || false,
                port: pressurePort?.path,
                baudRate: pressurePort?.baudRate
            },
            temp: {
                connected: tempPort?.isOpen || false,
                port: tempPort?.path,
                baudRate: tempPort?.baudRate
            },
            weight: {  // เพิ่มสถานะเครื่องชั่ง
                connected: weightPort?.isOpen || false,
                port: weightPort?.path,
                baudRate: weightPort?.baudRate
            }
        };
        
        io.emit('connectionStatus', status);
    }

    // เรียกใช้ฟังก์ชันนี้หลังจากการเชื่อมต่อหรือยกเลิกการเชื่อมต่อ
    socket.on('connect', () => {
        console.log('Client connected');
        updateConnectionStatus();  // ส่งสถานะทันทีที่ client เชื่อมต่อ
    });

    // เพิ่ม socket event สำหรับหน้า thank you
    socket.on('thankyouPage', async (data) => {
        try {
            await saveMeasurements({ ...data, currentPage: 'thankyou' });
            io.emit('dataSaved', {
                success: true,
                message: 'บันทึกข้อมูลสำเร็จ'
            });
        } catch (error) {
            console.error('Error on thank you page:', error);
            io.emit('dataSaved', {
                success: false,
                message: 'เกิดข้อผิ��พลาดในการบันทึกข้อมูล: ' + error.message
            });
        }
    });

    // เพิ่ม handler สำหรับ saveVitalSigns
    socket.on('saveVitalSigns', async (data, callback) => {
        try {
            console.log('กำลังบันทึกข้อมูล:', data);
            
            // เรียกใช้ฟังก์ชัน saveVitalSigns
            await saveVitalSigns(data);
            
            // ส่งผลลัพธ์กลับไปยัง client
            callback({
                success: true,
                message: 'บันทึกข้อมูลสำเร็จ'
            });
            
        } catch (error) {
            console.error('เกิดข้อผิดพลาดในการบันทึกข้อมูล:', error);
            callback({
                success: false,
                message: error.message
            });
        }
    });

    // ส่งค่า config เมื่อ client ร้องขอ
    socket.on('getColorConfig', async (callback) => {
        const config = await readColorConfig();
        if (typeof callback === 'function') {
            callback(config);
        }
    });

    // บันทึกค่า config เมื่อ client ส่งมา
    socket.on('saveColorConfig', async (settings, callback) => {
        try {
            await saveColorConfig(settings);
            io.emit('colorConfigUpdated', settings); // แจ้งเตือน clients ทุกตัว
            if (typeof callback === 'function') {
                callback({ success: true });
            }
        } catch (error) {
            console.error('Error saving color config:', error);
            if (typeof callback === 'function') {
                callback({ success: false, error: error.message });
            }
        }
    });

    // เพิ่ม handler สำหรับควบคุม relay
    socket.on('controlRelay', async (data) => {
        try {
            if (!relayDevice) {
                const deviceConfig = {
                    vendorId: 0x16c0,
                    productId: 0x05df,
                    product: 'USBRelay2'
                };

                const deviceInfo = await findUSBRelay(deviceConfig);
                if (!deviceInfo) {
                    throw new Error('ไม่พบ USB Relay');
                }

                relayDevice = new HID.HID(deviceInfo.path);
                await new Promise(resolve => setTimeout(resolve, 100));
            }

            if (data.action === 'on') {
                relayDevice.sendFeatureReport([0, 0xFF, data.relay]);
                console.log(`เปิด relay ${data.relay}`);
            } else {
                relayDevice.sendFeatureReport([0, 0xFD, data.relay]);
                console.log(`ปิด relay ${data.relay}`);
            }

        } catch (err) {
            console.error('เกิดข้อผิดพลาดในการควบคุม relay:', err);
            relayDevice = null; // รีเซ็ต device instance เมื่อเกิดข้อผิดพลาด
            socket.emit('relayError', {
                message: 'เกิดข้อผิดพลาดในการควบคุม relay: ' + err.message
            });
        }
    });

    // เพิ่ม cleanup เมื่อ disconnect
    socket.on('disconnect', () => {
        if (relayDevice) {
            try {
                relayDevice.close();
                relayDevice = null;
            } catch (err) {
                console.error('Error closing relay device:', err);
            }
        }
    });
});

// เพิ่ม middleware สำหรับตรวจบการเข้าถึงหน้า
async function checkPageAccess(req, res, next) {
    try {
        const config = await validateDisplayConfig();
        const requestedPage = req.path.substring(1); // ตัด / ออกจา path
        
        // ถ้าเป็นหน้าหลัก��รือหน้าตั้งค่า ให้ผ่านไปได้เลย
        if (requestedPage === '' || requestedPage === 'settings') {
            return next();
        }
        
        // ตรวจสอบว่าหน้านี้เปิดใช้งานหรือไม่
        if (config.enabled[requestedPage] === false) {
            // ถ้าปิดใช้งาน ให้ redirect ไปหน้าแรก
            return res.redirect('/');
        }
        
        next();
    } catch (error) {
        console.error('Error checking page access:', error);
        res.redirect('/');
    }
}

// ใช้ middleware กับทุก route
app.use(checkPageAccess);

// Routes
app.get('/', (req, res) => {
    
    
    res.render('search', { 
        title: 'ค้นหาผู้ป่วย'
    });
});

app.get('/patients', (req, res) => {
    res.render('patients', { patients: [] });
});


// เพิ่ม route สำหรับหน้ารวม
app.get('/combined', (req, res) => {
    // รีเซ็ตค่า lastReadings
    lastReadings = {
        systolic: null,
        diastolic: null,
        pulse: null,
        temperature: null
    };
    
    res.render('combined', { 
        readings: {
            systolic: '-',
            diastolic: '-',
            pulse: '-',
            temperature: '-'
        } 
    });
});

// เพิ่ม routes สำหรับแต่ละหน้า
app.get('/search', (req, res) => {
    res.render('search', { 
        title: 'ค้นหาผู้ป่วย'
    });
});

app.get('/temperature', (req, res) => {
    res.render('temperature', { 
        title: 'วัดอุณหภูมิ'
    });
});

// เพิ่ม route สำหรับหน้��� BMI
app.get('/bmi', (req, res) => {
    res.render('bmi');
});

app.get('/pressure', (req, res) => {
    res.render('pressure', { 
        title: 'วัดความดัน',
        readings: {
            systolic: '-',
            diastolic: '-',
            pulse: '-'
        } 
    });
});

// เ���ิ่ม route สำหรับ next-page
app.get('/next-page', async (req, res) => {
    const currentPage = req.query.from;
    const nextPage = await getNextPage(currentPage);
    
    // ตรวจสอบว่าหน้าถัดไปมีอยู่ในการตั้งค่าหรือไม่
    const config = await validateDisplayConfig();
    if (nextPage !== '/' && !config.enabled[nextPage.substring(1)]) {
        res.redirect('/');
    } else {
        res.redirect(nextPage);
    }
});

// เพิ่มเส้นทาง config
const displayConfigPath = path.join(__dirname, 'config', 'displayConfig.json');

// เพิ่มฟังก์ชันสำหรับอ่าน display config
async function getDisplayConfig() {
    try {
        const data = await fsPromises.readFile(displayConfigPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading display config:', error);
        // ส่งค่าเริ่มต้นถ้าอ่า���ไ��ล์ไม่ได้
        const defaultConfig = {
            enabled: {
                temp: true,
                pressure: true,
                bmi: true
            },
            order: ["temp", "pressure", "bmi"]
        };
        
        // ส��้างไฟล์ config ถ้ายังไม่มี
        try {
            await fsPromises.writeFile(
                displayConfigPath, 
                JSON.stringify(defaultConfig, null, 4)
            );
        } catch (writeError) {
            console.error('Error creating default display config:', writeError);
        }
        
        return defaultConfig;
    }
}

// เพิ่มังก์ชันสำหรับตั้งค่า event listeners
function setupPortListeners(port, type) {
    port.on('error', (err) => {
        console.error(`${type} port error:`, err);
        handlePortDisconnection(type);
    });

    port.on('close', () => {
        console.log(`${type} port closed`);
        handlePortDisconnection(type);
    });
}

// เพิ่มฟังก์ชันจัดการเมื่อพอร์ตหลุด
async function handlePortDisconnection(type) {
    // ยกเ���ิก timer เดิม (ถ้ามี)
    if (reconnectTimers[type]) {
        clearTimeout(reconnectTimers[type]);
    }

    // อัพเดทสถานการเชื่อมต่อ
    connectionStatus[type] = { connected: false, connecting: false };
    io.emit('connectionStatus', connectionStatus);

    // ดึงค่า config ล่าสุด
    const config = JSON.parse(fs.readFileSync('config/portConfig.json', 'utf8'));
    const portConfig = config.ports[type];

    // ตรวจสอบว่าพอร์ตถูกเิดใช้งานอยู่หรือไม่
    if (portConfig && portConfig.enabled) {
        console.log(`Attempting to reconnect ${type} port in 5 seconds...`);
        
        // ตังเวลาลงเชื่อมต่อใหม่ทุก 5 วินาท
        reconnectTimers[type] = setTimeout(async () => {
            try {
                const success = await connectPort(
                    portConfig.path,
                    type,
                    portConfig.baudRate,
                    type === 'pressure' ? { model: portConfig.model || 'inbody1' } : undefined
                );
                
                if (!success) {
                    // ถ้าเชื่อมต่อไม่สำเร็จ ให้ลองใหม่
                    handlePortDisconnection(type);
                }
            } catch (error) {
                console.error(`Error reconnecting ${type} port:`, error);
                // ถ้าเกิดข้อผิดพลาด ห้ลองใหม่
                handlePortDisconnection(type);
            }
        }, 5000);
    }
}

// เพิ่มฟังก์ชั��สำหรับอ่านค่า��ุณหภูมิ
function setupTempPortReader(port) {
    console.log('=== Temperature Port Setup ===');
    console.log('Port path:', port.path);
    
    // ใช้ parser แบบ delimiter ที่ชัดเจน
    const parser = port.pipe(new ReadlineParser({ 
        delimiter: '\r\n',
        encoding: 'utf8'
    }));

    // แสดงข้อมูลดิบทุกครั้งที่ได้รับ
    port.on('data', (buffer) => {
        console.log('\n=== Raw Temperature Data ===');
        console.log('UTF8:', buffer.toString('utf8'));
    });

    // ��ีกา��จั���การข้อมูลที่ชัดเ��นผ่าน parser
    parser.on('data', (line) => {
        try {
            console.log('\n=== Parsed Temperature Line ===');
            console.log('Line:', line);

            // ค้นาค่าอุณหภูมิ
            if (line.includes('T body =')) {
                const match = line.match(/T body = (\d+\.\d+)/);
                if (match) {
                    const temp = parseFloat(match[1]).toFixed(1);
                    console.log('Found temperature:', temp);
                    lastReadings.temperature = temp;
                    io.emit('temperature', temp);
                }
            }
            // ����พ���่มการค้นหา T Object ถ้าไม่พบ T body
            else if (line.includes('T Object =')) {
                const match = line.match(/T Object = (\d+\.\d+)/);
                if (match) {
                    const temp = parseFloat(match[1]).toFixed(1);
                    console.log('Found object temperature:', temp);
                    lastReadings.temperature = temp;
                    io.emit('temperature', temp);
                }
            }
        } catch (error) {
            console.error('Error parsing temperature data:', error);
        }
    });

    // ัดการข้ผิดพลาด
    parser.on('error', (err) => {
        console.error('Temperature parser error:', err);
    });
}

// แก้ไขฟังก์ชันสำหร���บอ่าน���่าความดัน
function setupPressurePortReader(port) {
    console.log('=== Pressure Port Setup ===');
    console.log('Port path:', port.path);
    
    let dataBuffer = ''; // เพิ่มตัวแปรสำหรับเก็บข้อม���ล

    // รบข้อมูลดิบจากพอร์ต
    port.on('data', (buffer) => {
        const data = buffer.toString('utf8');
        dataBuffer += data; // เก็บข้อมูลในบัฟเฟอร์
        
        // เมื่อพบ \r หรื�� \n แสดงว่าจ�����รรท��ด
        if (data.includes('\r') || data.includes('\n')) {
            console.log('\n=== Complete Pressure Data ===');
            console.log('Data:', dataBuffer);
            
            // ่งข้อมูลไปแปลงค่า
            const readings = parsePressureData(dataBuffer, 'omron9020');
            if (readings) {
                handlePressureReadings(readings);
            }
            
            // รีเซ็ตบัฟเฟอร์
            dataBuffer = '';
        }
    });

    // จัดการข้อผิดพลาด
    port.on('error', (err) => {
        console.error('Pressure port error:', err);
    });
}

// แก้ไขฟังก์ชันอ่าน config ต่างๆ
async function readPortConfig() {
    try {
        const configPath = path.join(__dirname, 'config', 'portConfig.json');
        const data = await fsPromises.readFile(configPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        if (error.code === 'ENOENT') {
            const defaultConfig = { ports: {} };
            await savePortConfig(defaultConfig);
            return defaultConfig;
        }
        console.error('Error reading port config:', error);
        return { ports: {} };
    }
}

async function savePortConfig(config) {
    try {
        const configPath = path.join(__dirname, 'config', 'portConfig.json');
        await fsPromises.writeFile(configPath, JSON.stringify(config, null, 4));
        return true;
    } catch (error) {
        console.error('Error saving port config:', error);
        return false;
    }
}

// อัพเดทฟัง���์ชันยกเลิกการเชื่อมต่อ
async function disconnectPort(type) {
    try {
        // ยกเลก timer reconnect
        if (reconnectTimers[type]) {
            clearTimeout(reconnectTimers[type]);
            reconnectTimers[type] = null;
        }
         // เลือกพอร์ตตามประเภท
         let port;
         switch(type) {
             case 'pressure':
                 port = pressurePort;
                 break;
             case 'temp':
                 port = tempPort;
                 break;
             case 'weight':
                 port = weightPort;
                 break;
             default:
                 port = null;
         }

         if (port && port.isOpen) {
            await new Promise((resolve) => port.close(resolve));
        }

        // อัพดท portConfig เมื่อยกเลิกการเชื่อมต่อ
        const config = JSON.parse(fs.readFileSync('config/portConfig.json', 'utf8'));
        if (config.ports[type]) {
            config.ports[type].enabled = false;
            fs.writeFileSync('config/portConfig.json', JSON.stringify(config, null, 4));
        }

        connectionStatus[type] = { connected: false, connecting: false };
        io.emit('connectionStatus', connectionStatus);
        return true;
    } catch (error) {
        console.error(`Error disconnecting ${type} port:`, error);
        return false;
    }
}

// อัพเดทฟังก์ชัน initializePortConnections
async function initializePortConnections() {
    try {
        const config = await readPortConfig();
        console.log('Port configuration loaded:', config);

        if (config.ports) {
            // เชื่อมต่อถ้ามีข้อมูลพอร์ตใน config
            if (config.ports.pressure?.path) {
                console.log('Attempting to connect pressure port:', config.ports.pressure.path);
                await connectPort(config.ports.pressure.path, 'pressure', config.ports.pressure.baudRate);
            }

            if (config.ports.temp?.path) {
                console.log('Attempting to connect temperature port:', config.ports.temp.path);
                await connectPort(config.ports.temp.path, 'temp', config.ports.temp.baudRate);
            }

            // เพิ่มการเชื่อมต่อเครื่องชั่ง
            if (config.ports.weight?.path) {
                console.log('Attempting to connect weight port:', config.ports.weight.path);
                await connectPort(config.ports.weight.path, 'weight', config.ports.weight.baudRate);
            }
        }
    } catch (error) {
        console.error('Error initializing port connections:', error);
    }
}

// แก้ไขส่วนเริ่มต้น server
const PORT = process.env.PORT || 3000;
const server = http.listen(PORT, async () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Open http://localhost:${PORT} in your browser`);
    
    try {
        // ทดสอบการเชื่อมต่อฐานข้อมูล
        const connection = await pools.primary.getConnection();
        console.log('Database connected successfully');
        connection.release();

        // เพิ่มการเชื่อมต่อพอร์ตอัตโนมัติ
        await initializePortConnections();
        
        // เพิ่มการตรวจสอบ display config
        await validateDisplayConfig();
    } catch (error) {
        console.error('Startup error:', error);
    }
});

// เพิ่มฟังก์ชันตรวจสอบสถานะพอร์ต
function checkPortStatus() {
    return {
        pressure: {
            connected: pressurePort?.isOpen || false,
            path: pressurePort?.path || null
        },
        temp: {
            connected: tempPort?.isOpen || false,
            path: tempPort?.path || null
        },
        weight: {
            connected: weightPort?.isOpen || false,
            path: weightPort?.path || null
        }
    };
}

// เพิ่มฟ���งก์ชันสำหรัการตั้งค่าหน้าถัดไป
async function getNextPage(currentPage) {
    try {
        const config = await validateDisplayConfig();
        const enabledPages = config.order.filter(page => config.enabled[page]);

        // ถ้าไม่มีหน้าที่���ปิดใช้งานเลย ให้ก���ับไปหน้าแรก
        if (enabledPages.length === 0) {
            return '/';
        }

        // ถ้������ยู่หน������าแร�����ห�����อไม่มี���น้าปั���จุบัน
        if (currentPage === 'search' || !currentPage) {
            return `/${enabledPages[0]}`;
        }

        // ��า��น�����ถัด��ป��ี่เปิดใช้งาน
        const currentIndex = enabledPages.indexOf(currentPage);
        if (currentIndex === -1 || currentIndex === enabledPages.length - 1) {
            return '/'; // กลับไปหน้าแรกถ้าเป็นหน้าสุดท้ายหรือไม่พบหน้าปัจจุบัน
        }
        
        return `/${enabledPages[currentIndex + 1]}`;
    } catch (error) {
        console.error('Error getting next page:', error);
        return '/';
    }
}
// เพิ่มฟังก์ชัน��ำหรับอ่านข้อมูลบัตร
async function readThaiIDCard(card) {
    try {
        // Select Thai ID Card Applet
        const selectResponse = await retry(async () => {
            const response = await card.issueCommand([
                0x00, 0xA4, 0x04, 0x00, 0x08,
                0xA0, 0x00, 0x00, 0x00, 0x54,
                0x48, 0x00, 0x01
            ]);
            await delay(100);
            return response;
        });

        // อ่านเลขบัตรประชาชน
        const cidResponse = await retry(async () => {
            const response = await card.issueCommand([
                0x80, 0xb0, 0x00, 0x04, 0x02, 0x00, 0x0d
            ]);
            await delay(100);
            return response;
        });

        if (cidResponse[cidResponse.length - 2] === 0x61) {
            const getResponse = await retry(async () => {
                return await card.issueCommand([
                    0x00, 0xC0, 0x00, 0x00, cidResponse[cidResponse.length - 1]
                ]);
            });
            try {
                const cidData = Buffer.from(getResponse.slice(0, -2));
                const cid = iconv.decode(cidData, 'tis620').trim();
                console.log('เลขบัตรประชาชนที่ได้:', cid);
                console.log('ความยาวของเลขบัตร:', cid.length);
                console.log('รูปแบบข้อมูล:', typeof cid);
                
                io.emit('cardInserted', { cid: cid });
                
            } catch (error) {
                console.log('ข้อผิดพลาดในการอ่านบัตร:', error);
                console.log('ข้อมูลดบ (CID):', getResponse.slice(0, -2).toString('hex'));
            }
        }

        await delay(200); // อก่อนอ่าข้อมูลถัดไป

        // อ่านชื่อ-นามสกุล ภาษาไทย
        const nameResponse = await retry(async () => {
            const response = await card.issueCommand([
                0x80, 0xb0, 0x00, 0x11, 0x02, 0x00, 0x64
            ]);
            await delay(100);
            return response;
        });

        if (nameResponse[nameResponse.length - 2] === 0x61) {
            const getResponse = await retry(async () => {
                return await card.issueCommand([
                    0x00, 0xC0, 0x00, 0x00, nameResponse[nameResponse.length - 1]
                ]);
            });
            try {
                const nameData = Buffer.from(getResponse.slice(0, -2));
                const thName = iconv.decode(nameData, 'tis620').trim();
                console.log('ชื่อ-นามสกุล:', thName.replace(/#/g, ' ').trim());
            } catch (error) {
                console.log('ข้อมูลดิบ (Name):', getResponse.slice(0, -2).toString('hex'));
            }
        }

    } catch (error) {
        console.error('เกิดข้อผิดพลาดใ��การอ่า��บัตร:', error);
    }
}

console.log("รอการเชื่อมต่อเครื่องอ่านบัตร...");

devices.on('device-activated', event => {
    const device = event.device;
    console.log(`พบเครื่องอ่านบัตร: ${device}`);

    device.on('card-inserted', async event => {
        const card = event.card;
        console.log(`มีการเสียบบัตร ATR:`, card.getAtr().toString('hex'));
        await delay(500); // รอให้บัตรพร้อมก่อนอ่าน
        await readThaiIDCard(card);
    });

    device.on('card-removed', () => {
        console.log(`มีการดึงบัตรออก`);
    });

    device.on('error', error => {
        console.error(`เกิดข้อผิดพลาดที่เครื่องอ่านบัตร:`, error.message);
    });
});

devices.on('device-deactivated', event => {
    console.log(`ถอดเครื่องอ่านบัตรออก: ${event.device}`);
});

devices.on('error', error => {
    console.error(`เกิดข้อผิดพลาดที่ระบบ:`, error.message);
});


// เพิ่มฟังก์ชันสำหรับแยกวิเคราะห์��้อมูลตามรุ่น
function parsePressureData(data, model) {
    try {
        console.log('Parsing data for model:', model);
        console.log('Raw data:', data);
        
        switch (model) {
            case 'omron9020':
                // ตรวจสอบรูปแบบข้อมูล: bp,99999999999999999999,2024/11/16,07:49,114,084,069,067,0
                if (data.startsWith('bp,')) {
                    const values = data.split(',');
                    if (values.length >= 8) {
                        const sys = parseInt(values[4]);
                        const dia = parseInt(values[6]);
                        const pulse = parseInt(values[7]);
                        
                        console.log('Parsed values:', { sys, dia, pulse });
                        
                        if (!isNaN(sys) && !isNaN(dia) && !isNaN(pulse)) {
                            return {
                                systolic: sys,
                                diastolic: dia,
                                pulse: pulse
                            };
                        }
                    }
                }
                break;

            case 'inbody1':
                const match1 = data.match(/RBS(\d{2,3})M\d{3}D(\d{2,3})P(\d{2,3})/);
                if (match1) {
                    return {
                        systolic: parseInt(match1[1]),
                        diastolic: parseInt(match1[2]),
                        pulse: parseInt(match1[3])
                    };
                }
                break;

            case 'inbody302':
                if (data.includes('RB') && data.includes('S') && data.includes('M') && 
                    data.includes('D') && data.includes('P')) {
                    
                    const systolicMatch = data.match(/S(\d{3})/);
                    const diastolicMatch = data.match(/D(\d{3})/);
                    const pulseMatch = data.match(/P(\d{3})/);

                    if (systolicMatch && diastolicMatch && pulseMatch) {
                        return {
                            systolic: parseInt(systolicMatch[1]),
                            diastolic: parseInt(diastolicMatch[1]),
                            pulse: parseInt(pulseMatch[1])
                        };
                    }
                }
                break;

            case 'omron':
                // รูปแบบ: YYYY,MM,DD,HH,mm,____,0,SYS,DIA,PR,0
                const values = data.split(',');
                if (values.length >= 11) {
                    const sys = parseInt(values[7].trim());
                    const dia = parseInt(values[8].trim());
                    const pr = parseInt(values[9].trim());
                    
                    if (!isNaN(sys) && !isNaN(dia) && !isNaN(pr)) {
                        return {
                            systolic: sys,
                            diastolic: dia,
                            pulse: pr
                        };
                    }
                }
                break;
        }
        return null;
    } catch (error) {
        console.error('Error parsing pressure data:', error);
        return null;
    }
}

// แก้ไขฟังก์ชัน readColorConfig
async function readColorConfig() {
    try {
        const configPath = path.join(__dirname, 'config', 'colorConfig.json');
        const data = await fsPromises.readFile(configPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        if (error.code === 'ENOENT') {
            // ถ้าไม่มีไฟล์ config ให้สร้างค่าเริ่มต้น
            const defaultConfig = {
                temp: {
                    feverThreshold: 37.5,
                    normalColor: '#198754',
                    feverColor: '#dc3545'
                },
                sys: {
                    low: 90,
                    high: 140,
                    lowColor: '#ffc107',
                    normalColor: '#198754',
                    highColor: '#dc3545'
                },
                dia: {
                    low: 60,
                    high: 90,
                    lowColor: '#ffc107',
                    normalColor: '#198754',
                    highColor: '#dc3545'
                }
            };
            await saveColorConfig(defaultConfig);
            return defaultConfig;
        }
        console.error('Error reading color config:', error);
        return null;
    }
}

async function saveColorConfig(config) {
    try {
        const configPath = path.join(__dirname, 'config', 'colorConfig.json');
        await fsPromises.writeFile(configPath, JSON.stringify(config, null, 4));
        return true;
    } catch (error) {
        console.error('Error saving color config:', error);
        return false;
    }
}

// เพิ่มฟังก์ชันสำหรับบนทึกข้อมูล
async function saveVitalSigns(data) {
    let primaryConnection;
    try {
        console.log('Attempting to save vital signs:', data);
        
        if (!data.hn || !data.vn) {
            throw new Error('ไม่พบข้อมูล HN หรือ VN');
        }
        const dbConfig = require('./config/dbConfig.json');
        const useSecondaryDb = dbConfig.useSecondaryDb;
        if (useSecondaryDb) {
            const staffConfig = await readStaffConfig();
            primaryConnection = await pools.secondary.getConnection();
            let bmi = 0;
            if (data.weight && data.height) {
                bmi = data.weight / ((data.height / 100) * (data.height / 100));
            }
        
           // สร้าง object สำหรับ HL7 message
           const hl7Data = {
            hn: data.hn,
            vn: data.vn,
            diastolic: data.diastolic || 0,
            systolic: data.systolic || 0,
            pulse: data.pulse || 0,
            temperature: data.temperature || 0,
            weight: data.weight || 0,
            height: data.height || 0,
            bmi: bmi.toFixed(2),
            respiratoryRate: data.respiratoryRate || 0,
            heartRate: data.heartRate || 0,
            dtx: data.dtx || 0,
            staff: staffConfig.staffName || null
        };
            const hl7Message = createHL7Message(hl7Data);
          

               // หา ID ถัดไป
            const [rows] = await primaryConnection.execute(
                'SELECT MAX(scn_result_id) as max_id FROM scn_result'
            );
            const nextId = (rows[0].max_id || 0) + 1;
            
            // สร้างวันเวลาปัจจุบัน
            const now = new Date();
            const thaiYear = now.getFullYear() + 543;
            const currentDate = now.toLocaleString('th-TH', {
                timeZone: 'Asia/Bangkok',
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false
            });

            // แปลงรูปแบบวันที่ให้ตรงกับ MySQL
            const [datePart, timePart] = currentDate.split(' ');
            const [day, month, year] = datePart.split('/');
            const mysqlDatetime = `${now.getFullYear()}-${month.padStart(2, '0')}-${day.padStart(2, '0')} ${timePart}`;

            // เตรียมข้อมูลสำหรับ INSERT
            const insertValues = [
                nextId,  // ต้องกำหนดค่าตามที่ต้องการ
                'an',  // ต้องกำหนดค่าตามที่ต้องการ
                null,     // ต้องกำหนดค่าตามที่ต้องการ
                'ORU^R01',      // ต้องกำหนดค่าตามที่ต้องการ
                hl7Message,   // ต้องกำหนดค่าตามที่ต้องการ
                mysqlDatetime, // ใช้วันที่ที่แปลงแล้ว
                'N',  // ต้องกำหนดค่าตามที่ต้องการ
                mysqlDatetime, // ใช้วันที่ที่แปลงแล้วสำหรับ receive_datetime
                staffConfig.staffName || null   // ต้องกำหนดค่าตามที่ต้องการ
            ];

            const insertQuery = `
                INSERT INTO scn_result (
                    scn_result_id,
                    scn_identify_patient_type,
                    scn_result_no,
                    scn_result_msg_type,
                    scn_result_data,
                    scn_result_stamp_datetime,
                    scn_result_receive_status,
                    scn_result_receive_datetime,
                    scn_machine_name
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            `;

            // เพิ่ม logging เพื่อตรวจสอบค่า
            console.log('MySQL Datetime:', mysqlDatetime);
            console.log('Insert Values:', insertValues);

            await primaryConnection.execute(insertQuery, insertValues);

            console.log('HL7 message saved successfully');

            io.emit('dataSaved', {
                success: true,
                message: 'บันทึกข้อมูลสำเร็จ'
            });


        } else {
            primaryConnection = await pools.primary.getConnection();
        
        await primaryConnection.beginTransaction();

        // กรณีที่ 1: มีทั้งหมด
        if (data.systolic > 0 && data.diastolic > 0 && data.pulse > 0 && 
            data.temperature && data.weight && data.height) {
            
            let temp = parseFloat(data.temperature);
            let weight = parseFloat(data.weight);
            let height = parseFloat(data.height);

            const allDataQuery = `
            UPDATE opdscreen 
            SET bpd = ?, bps = ?, pulse = ?, temperature = ?, 
                bw = ?, height = ?, bmi = ?,
                vstdate = CURDATE(), vsttime = CURTIME()
            WHERE hn = ? AND vn = ?
            `;

            // ค���นว�� BMI
            const bmi = weight / ((height / 100) * (height / 100));

            const allDataValues = [
                data.diastolic,
                data.systolic,
                data.pulse,
                temp,
                weight,
                height,
                bmi.toFixed(2),
                data.hn,
                data.vn
            ];

            // บันทึก opdscreen_bp ด้วย
            const bpQuery = `
                INSERT INTO opdscreen_bp 
                (opdscreen_bp_id, vn, bps, bpd, pulse, temperature, staff, screen_date, screen_time)
                VALUES ((SELECT COALESCE(MAX(opdscreen_bp_id), 0) + 1 FROM opdscreen_bp b), 
                        ?, ?, ?, ?, ?, ?, CURDATE(), CURTIME())
            `;

            const staffConfig = await readStaffConfig();
            const bpValues = [
                data.vn,
                data.systolic,
                data.diastolic,
                data.pulse,
                temp,
                staffConfig.staffName || null
            ];

            const [updateResult] = await primaryConnection.execute(allDataQuery, allDataValues);
            if (updateResult.affectedRows === 0) {
                throw new Error('ไม่พบข้อมูลผู้ป่วยในระบบ');
            }

            await primaryConnection.execute(bpQuery, bpValues);
            await primaryConnection.commit();
            console.log('บันทึกข้อมูลทั้งหมดสำเร็จ');
        }
        // กรณีที่ 2: มีแค่ความดันและอุณหภูมิ
        else if (data.systolic > 0 && data.diastolic > 0 && data.pulse > 0) {
            let temp = null;
            if (data.temperature && data.temperature !== '-') {
                temp = parseFloat(data.temperature);
                if (isNaN(temp)) temp = null;
            }

            const bpTempQuery = `
            UPDATE opdscreen 
            SET bpd = ?, bps = ?, pulse = ?, temperature = ?, 
                vstdate = CURDATE(), vsttime = CURTIME()
            WHERE hn = ? AND vn = ?
            `;

            const bpTempValues = [
                data.diastolic,
                data.systolic,
                data.pulse,
                temp,
                data.hn,
                data.vn
            ];

            const bpQuery = `
                INSERT INTO opdscreen_bp 
                (opdscreen_bp_id, vn, bps, bpd, pulse, temperature, staff, screen_date, screen_time)
                VALUES ((SELECT COALESCE(MAX(opdscreen_bp_id), 0) + 1 FROM opdscreen_bp b), 
                        ?, ?, ?, ?, ?, ?, CURDATE(), CURTIME())
            `;

            const staffConfig = await readStaffConfig();
            const bpValues = [
                data.vn,
                data.systolic,
                data.diastolic,
                data.pulse,
                temp,
                staffConfig.staffName || null
            ];

            const [updateResult] = await primaryConnection.execute(bpTempQuery, bpTempValues);
            if (updateResult.affectedRows === 0) {
                throw new Error('ไม่พบข้อมูลผู้ป่วยในระบบ');
            }

            await primaryConnection.execute(bpQuery, bpValues);
            await primaryConnection.commit();
            console.log('บันทึกข้อมูลความดันและอุณหภูมิสำเร็จ');
        }
        // กรณีที่ 3: มีแค่อุณหภูมิ
        else if (data.temperature) {
            let temp = parseFloat(data.temperature);
            if (isNaN(temp)) {
                throw new Error('ค่าอุณหภูมิไม่ถูกต้อง');
            }

            const tempQuery = `
            UPDATE opdscreen 
            SET temperature = ?, 
                vstdate = CURDATE(), vsttime = CURTIME()
            WHERE hn = ? AND vn = ?
            `;

            const tempValues = [temp, data.hn, data.vn];

            const [updateResult] = await primaryConnection.execute(tempQuery, tempValues);
            if (updateResult.affectedRows === 0) {
                throw new Error('ไม่พบข้อมูลผู้ป่วยในระบบ');
            }

            await primaryConnection.commit();
            console.log('บันทึกข้อมูลอุณหภูมิสำเร็จ');
        }
        // กรณีที่ 4: มีแค่น้ำ��นัก-ส่วนสูง
        else if (data.weight && data.height) {
            let weight = parseFloat(data.weight);
            let height = parseFloat(data.height);
            
            // คำนวณ BMI
            const bmi = weight / ((height / 100) * (height / 100));

            const bmiQuery = `
            UPDATE opdscreen 
            SET bw = ?, height = ?, bmi = ?,
                vstdate = CURDATE(), vsttime = CURTIME()
            WHERE hn = ? AND vn = ?
            `;

            const bmiValues = [
                weight,
                height,
                bmi.toFixed(2),
                data.hn,
                data.vn
            ];

            const [updateResult] = await primaryConnection.execute(bmiQuery, bmiValues);
            if (updateResult.affectedRows === 0) {
                throw new Error('ไม่พบข้อมูลผู้ป่วยในระบบ');
            }

            await primaryConnection.commit();
            console.log('บันทึกข้อมูลน้ำหนักและส่วนสูงสำเร็จ');
        } else {
            throw new Error('ไม่พบข้อมูลที่จะบันทึก');
        }

        io.emit('dataSaved', {
            success: true,
            message: 'บันทึกข้อมูลสำเร็จ'
        });
    }
    } catch (error) {
        if (primaryConnection) {
            await primaryConnection.rollback();
        }
        console.error('Error saving vital signs:', error);
        io.emit('dataSaved', {
            success: false,
            message: 'เกิดข้อผิดพลาดในการบันทึกข้อมูล: ' + error.message
        });
    } finally {
        if (primaryConnection) {
            primaryConnection.release();
        }
    }
}
// เพิ่มฟังก์ชันสร้าง HL7 message
function createHL7Message(data) {
    const now = new Date();
    const timestamp = now.getFullYear() + 
        String(now.getMonth() + 1).padStart(2, '0') +
        String(now.getDate()).padStart(2, '0') +
        String(now.getHours()).padStart(2, '0') +
        String(now.getMinutes()).padStart(2, '0') +
        String(now.getSeconds()).padStart(2, '0');
    return [
        `MSH|^~\\&|${data.staff}|A and T|HIS|BMS-HOSxP|${timestamp}||ORU^R01|2701|P|2.3`,///
        `PID|1||${data.hn || '0000000'}|`,///
        `PV1|1|O|||||||||||||||||${data.vn || ''}`,///
        `OBR|1|||||${timestamp}||||||||${timestamp}`,///
        `OBX|1|ST|WEIGHT||${data.weight || '0'}|KG.|||||F|||${timestamp}`,//
        `OBX|2|ST|HEIGHT||${data.height || '0'}|CM.|||||F|||${timestamp}`,//
        `OBX|3|ST|BMI||${data.bmi || '0'}|Kg/m2|||||F|||${timestamp}`, //
        `OBX|4|ST|TEMP||${data.temperature || '0'}|C|||||F|||${timestamp}`,//
        `OBX|5|ST|SYSTOLIC||${data.systolic || '0'}|mmHg|||||F|||${timestamp}`,
        `OBX|6|ST|DIASTOLIC||${data.diastolic || '0'}|mmHg|||||F|||${timestamp}`,
        `OBX|7|ST|RR||${data.respiratoryRate || '0'}|RM|||||F|||${timestamp}`,
        `OBX|8|ST|PULSE||${data.pulse || '0'}|bpm|||||F|||${timestamp}`,
        `OBX|9|ST|HEARTRATE||${data.heartRate || '0'}|HRM|||||F|||${timestamp}`,
        `OBX|10|ST|DTX||${data.dtx || '0'}|mg/DL|||||F|||${timestamp}`
    ].join('\n');
}
// เพิ่มตัวแปรเก็บข้อมูลคนไข้ปัจจบัน
let currentPatient = null;

// เพิ่มตัวแปรสำหรับเก็บค่าการวัดครั้งล่าสุดที่บันทึกแล้ว
let lastSavedReadings = null;

// เพ��่มฟังก์ชันกลางสำหรั��จั���การการบันทึกข้อมูล
function handlePressureReadings(readings) {
    if (!isNaN(readings.systolic) && 
        !isNaN(readings.diastolic) && 
        !isNaN(readings.pulse)) {
        
        lastReadings = { ...lastReadings, ...readings };
        io.emit('pressure', {
            systolic: readings.systolic.toString(),
            diastolic: readings.diastolic.toString(),
            pulse: readings.pulse.toString()
        });

        // เม่ต้องบันทึกทันที เก็บค่าไว้ในตัว��ปรชั���วคราวเท่านั้น
        lastSavedReadings = { ...readings };
    }
}

// เพิ่มฟังก์ชันอ่านและบันทึก staff config
async function readStaffConfig() {
    try {
        const configPath = path.join(__dirname, 'config', 'staffConfig.json');
        const data = await fsPromises.readFile(configPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        if (error.code === 'ENOENT') {
            const defaultConfig = { staffName: '' };
            await saveStaffConfig(defaultConfig);
            return defaultConfig;
        }
        console.error('Error reading staff config:', error);
        return { staffName: '' };
    }
}

async function saveStaffConfig(config) {
    try {
        const configPath = path.join(__dirname, 'config', 'staffConfig.json');
        await fsPromises.writeFile(configPath, JSON.stringify(config, null, 4));
        return true;
    } catch (error) {
        console.error('Error saving staff config:', error);
        return false;
    }
}



// เพิ่มโค้ดนี��ในส่วนที่จัดการ socket หรือ connection
io.on('disconnect', () => {
  console.log('Client disconnected, shutting down server...');
  process.exit(0);
});

// ห���ือถ้าใช้ Express อย่างเดี��ว
app.on('close', () => {
  process.exit(0);
});

// เพิ่มฟังก์ชันสำหรับรีสตาร์ทเซิฟเวอร์
async function restartServer() {
    try {
        // แจ้งเตือน clients ทั้งหมดก่อน
        io.emit('serverRestarting', {
            message: 'กำลังรีสตาร์ทเซิฟเวอร์...'
        });

        // รอให้การส่งข้อมูลเสร็จ���มบูรณ��
        await new Promise(resolve => setTimeout(resolve, 1000));

        // ปิดการเชื่อมต่อ��านข้อมูลทั้งหมด
        try {
            if (pools.primary) {
                await pools.primary.end().catch(() => {});
            }
        } catch (error) {
            console.log('ไม่สามารถปิดการเชื่อมต่อฐานข้อมูลหลักได้:', error.message);
        }

        try {
            if (pools.secondary) {
                await pools.secondary.end().catch(() => {});
            }
        } catch (error) {
            console.log('ไม่สามารถปิดการเชื่อมต่อฐานข้อมูลรองได้:', error.message);
        }

        // ปิดการเชื่อมต่อพอร์ตทั้งหมด
        try {
            if (pressurePort) {
                await pressurePort.close().catch(() => {});
            }
        } catch (error) {
            console.log('ไม่สามารถ���ิดพอร์ตวัดความดันได้:', error.message);
        }

        try {
            if (tempPort) {
                await tempPort.close().catch(() => {});
            }
        } catch (error) {
            console.log('ไม่สามารถปิดพอร์ตวัดอุณหภูมิได้:', error.message);
        }

        // รอให้การเชื่อ���ต่อทั้งหมดปิดสมบูรณ์
        await new Promise(resolve => setTimeout(resolve, 1000));

        // ออกด้วยรห���สพิเศษ 100 เพื่อให้ server-manager รู้ว่าต้องรีสตาร์ท
        process.exit(100);
    } catch (error) {
        console.error('Error during server restart:', error);
        // ถึงแม้จะมี error ก็ให้พยายามปิดโปรแกรม
        process.exit(100);
    }
}


function findVideos(dir) {
    try {
        const videoExtensions = ['.mp4', '.webm', '.mov'];
        const files = fs.readdirSync(dir);
        return files
            .filter(file => {
                const ext = path.extname(file).toLowerCase();
                return videoExtensions.includes(ext);
            })
            .map(file => `/videos/${file}`);
    } catch (error) {
        console.error('Error finding videos:', error);
        return [];
    }
}

app.get('/api/videos', async (req, res) => {
    try {
        const videosDir = path.join(__dirname, 'public', 'videos');
        // สร้างโฟลเดอร์ถ้ายังไม่มี
        if (!fs.existsSync(videosDir)) {
            fs.mkdirSync(videosDir, { recursive: true });
        }
        
        const files = await readdir(videosDir);
        
        // กรองเฉพาะไฟล์วิดีโอและเพิ่ม log
        const videos = files.filter(file => {
            const isVideo = file.toLowerCase().match(/\.(mp4|webm|mov)$/);
            console.log(`Checking file: ${file}, isVideo: ${!!isVideo}`);
            return isVideo;
        });
        
        console.log('Found videos:', videos);
        
        res.json({ 
            success: true, 
            videos: videos 
        });
    } catch (error) {
        console.error('Error reading videos directory:', error);
        res.status(500).json({ 
            success: false, 
            error: 'ไม่สามารถอ่านรายการวิดีโอได้' 
        });
    }
});

// เพิ่มฟังก์ชันตรวจสอบและแก้ไข displayConfig
async function validateDisplayConfig() {
    try {
        const configPath = path.join(__dirname, 'config', 'displayConfig.json');
        let config;

        try {
            const data = await fsPromises.readFile(configPath, 'utf8');
            config = JSON.parse(data);
        } catch (error) {
            config = {
                enabled: {
                    temperature: true,
                    pressure: true,
                    bmi: true
                },
                order: [
                    "temperature",
                    "pressure",
                    "bmi"
                ]
            };
            await fsPromises.writeFile(configPath, JSON.stringify(config, null, 4));
        }

        return config;
    } catch (error) {
        console.error('Error validating display config:', error);
        return {
            enabled: {
                temperature: true,
                pressure: true,
                bmi: true
            },
            order: [
                "temperature",
                "pressure",
                "bmi"
            ]
        };
    }
}

// ��พิ่ม route สำหรับหน้า thankyou
app.get('/thankyou', (req, res) => {
    res.render('thankyou');
});

// ตั้งค่า multer สำห���ับจัดการไฟล์
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadsDir = path.join(__dirname, 'public', 'uploads');
        if (!fs.existsSync(uploadsDir)) {
            fs.mkdirSync(uploadsDir, { recursive: true });
        }
        cb(null, uploadsDir);
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const filename = 'welcome-' + uniqueSuffix + path.extname(file.originalname);
        console.log('Generated filename:', filename); // เพิ่ม log
        cb(null, filename);
    }
});

const upload = multer({ 
    storage: storage,
    fileFilter: function (req, file, cb) {
        // ตรวจสอบประเภทไฟล์
        if (!file.mimetype.startsWith('image/')) {
            return cb(new Error('เฉพาะไฟล์รูปภาพเท่านั้น'));
        }
        cb(null, true);
    }
});



// เพิ่ม endpoint สำหรับดึงการตั้งค่า
app.get('/api/welcome-settings', (req, res) => {
    try {
        res.json({
            success: true,
            settings: global.welcomeSettings || {
                hospitalName: '',
                welcomeImage: '/images/1.webp'
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'ไม่สามารถดึงการตั้งค่าได้'
        });
    }
});

// ตรวจสอบว่ามี middleware สำหรับ uploads
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads')));

function getServerIP() {
    const interfaces = os.networkInterfaces();
    let serverIP = 'localhost';
    
    // วนลูปหา IP address ที่ไม่ใช่ localhost
    Object.keys(interfaces).forEach((interfaceName) => {
        interfaces[interfaceName].forEach((interface) => {
            if (interface.family === 'IPv4' && !interface.internal) {
                serverIP = interface.address;
            }
        });
    });
    
    return serverIP;
}

io.on('connection', (socket) => {
    // ... socket events อื่นๆ ที่มีอยู��� ...

    socket.on('getServerIP', () => {
        socket.emit('serverIP', getServerIP());
    });
});

// เพิ่มตัวแปร global สำหรับเก็บการตั้งค่า
global.welcomeSettings = {
    hospitalName: 'โรงพยาบาลกรุงเทพ',
    welcomeImage: '/images/AT.jpg'
};

// เพิ่มฟังก์ชันสำหรบโหลดการตั้งค่า
async function loadWelcomeSettings() {
    try {
        const configPath = path.join(__dirname, 'config', 'welcome-settings.json');
        
        // สร้างโฟลเดอร์ config ถ้ายังไม่มี
        if (!fs.existsSync(path.join(__dirname, 'config'))) {
            fs.mkdirSync(path.join(__dirname, 'config'));
        }
        
        // โหลดการตั้งค่าจากไฟล์
        if (fs.existsSync(configPath)) {
            const settings = JSON.parse(await fsPromises.readFile(configPath, 'utf8'));
            global.welcomeSettings = settings;
            console.log('โหลดการตั้งค่าสำเร็จ:', settings);
        } else {
            // สร้างไฟล์ config เริ่มต้นถ้าย��งไม่มี
            await fsPromises.writeFile(
                configPath,
                JSON.stringify(global.welcomeSettings, null, 2)
            );
            console.log('สร้างไฟล์การตั้งค่าเริ่มต้น');
        }
    } catch (error) {
        console.error('Error loading welcome settings:', error);
    }
}

// เรียกใช้ฟังก์ชันเมื่อเริ่มต้น server
loadWelcomeSettings();

// แก้��ข endpoint สำหรับดึงการตั้งค่า
app.get('/api/welcome-settings', (req, res) => {
    res.json({
        success: true,
        settings: global.welcomeSettings
    });
});

// ลบ endpoint เดิมออก และใช้อันนี้อันเดียว
app.post('/api/welcome-settings', upload.single('welcomeImage'), async (req, res) => {
    try {
        console.log('Received file:', req.file);

        const configPath = path.join(__dirname, 'config', 'welcome-settings.json');
        const settings = {
            hospitalName: req.body.hospitalName || '',
            welcomeImage: global.welcomeSettings?.welcomeImage || '/images/1.webp'
        };

        if (req.file) {
            // กำหนด path ให้ถูกต้อง
            const filename = req.file.filename;
            settings.welcomeImage = `/uploads/${filename}`;
            
            console.log('File saved:', {
                originalPath: req.file.path,
                webPath: settings.welcomeImage
            });
        }

        // บันทึกการตั้งค���า
        await fsPromises.writeFile(configPath, JSON.stringify(settings, null, 2));
        global.welcomeSettings = settings;

        console.log('Settings saved:', settings);

        // ส่งการตั้งค่าใหม่ไปยังทุก client
        io.emit('welcomeSettingsUpdated', settings);
        
        res.json({
            success: true,
            settings: settings,
            imagePath: settings.welcomeImage
        });

    } catch (error) {
        console.error('Error saving welcome settings:', error);
        res.status(500).json({
            success: false,
            error: 'ไม่สามารถบันทึกการตั้งค่าได้: ' + error.message
        });
    }
});

// เพิ่ม middleware สำหรับโฟลเดอร์ uploads

// เพิ่ม route สำหรับอ่าน readings.json
app.get('/data/readings.json', (req, res) => {
    try {
        const readingsPath = path.join(__dirname, 'data', 'readings.json');
        const data = fs.readFileSync(readingsPath, 'utf8');
        res.json(JSON.parse(data));
    } catch (error) {
        console.error('Error reading readings.json:', error);
        res.status(500).json({ error: 'ไม่สามารถอ่านข้อมูลได้' });
    }
});

// เพิ่ม endpoint สำหรับดึงข้อมูลเจ้าหน้าที่
app.post('/staff-settings', async (req, res) => {
    try {
        console.log('Received request body:', req.body); // เพิ่ม log เพื่อดูข้อมูลที่ส่งมา
        const { staffName } = req.body;
        
        if (!staffName) {
            return res.status(400).json({
                success: false,
                error: 'กรุณาระบุชื่อเจ้าหน้าที่'
            });
        }
        const configPath = path.join(__dirname, 'config', 'staffConfig.json');
    

        // สร้างโฟลเดอร์ config ถ้ายังไม่มี
        if (!fs.existsSync(path.join(__dirname, 'config'))) {
            fs.mkdirSync(path.join(__dirname, 'config'));
        }

        // บันทึกข้อมูล
        const settings = { staffName: staffName };
        await fsPromises.writeFile(
            configPath,
            JSON.stringify(settings, null, 4)
        );

        res.json({
            success: true,
            message: 'บันทึกข้อมูลเรียบร้อยแล้ว'
        });
    } catch (error) {
        console.error('Error saving staff settings:', error);
        res.status(500).json({
            success: false,
            error: 'ไม่สามารถบันทึกข้อมูลเจ้าหน้าที่ได้'
        });
    }
});

// เพิ่ม endpoint สำหรับดึงข้อมูลเจ้าหน้าที่
app.get('/api/staff-settings', async (req, res) => {
    try {
        const configPath = path.join(__dirname, 'config', 'staffConfig.json');
        
        // ถ้าไม่มีไฟล์ config ให้ส่งค่าว่างกลับไป
        if (!fs.existsSync(configPath)) {
            return res.json({
                success: true,
                settings: { staffName: '' }
            });
        }

        // อ่านและส่งข้อมูลกลับ
        const data = await fsPromises.readFile(configPath, 'utf8');
        const settings = JSON.parse(data);
        
        res.json({
            success: true,
            settings: settings
        });
    } catch (error) {
        console.error('Error reading staff settings:', error);
        res.status(500).json({
            success: false,
            error: 'ไม่สามารถดึงข้อมูลเจ้าหน้าที่ได้'
        });
    }
});

// เพิ่ม route สำหรับดึงการตั้งค่าสี
app.get('/api/color-settings', (req, res) => {
    try {
        const configPath = path.join(__dirname, 'config', 'colorConfig.json');
        const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        res.json({ success: true, config });
    } catch (error) {
        console.error('Error reading color config:', error);
        res.status(500).json({ 
            success: false, 
            error: 'ไม่สามารถอ่านการตั้งค่าสีได้' 
        });
    }
});

// เพิ่ม route สำหรับบันทึกการตั้งค่าสี
app.post('/api/color-settings', (req, res) => {
    try {
        const configPath = path.join(__dirname, 'config', 'colorConfig.json');
        fs.writeFileSync(configPath, JSON.stringify(req.body, null, 2));
        res.json({ success: true });
    } catch (error) {
        console.error('Error saving color config:', error);
        res.status(500).json({ 
            success: false, 
            error: 'ไม่สามารถบันทึกการตั้งค่าสีได้' 
        });
    }
});

// ตั้งค่า multer สำหรับอัพโหลดวิดีโอ
const videoStorage = multer.diskStorage({
    destination: function (req, file, cb) {
        const dir = path.join(__dirname, 'public', 'videos');
        // สร้างโฟลเดอร์ถ้ายังไม่มี
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        cb(null, dir);
    },
    filename: function (req, file, cb) {
        // เก็บชื่อไฟล์เดิมและเพิ่ม timestamp
        const timestamp = Date.now();
        const ext = path.extname(file.originalname);
        const filename = `${path.basename(file.originalname, ext)}_${timestamp}${ext}`;
        cb(null, filename);
    }
});

const videoUpload = multer({
    storage: videoStorage,
    fileFilter: function (req, file, cb) {
        // ตรวจสอบประเภทไฟล์
        if (file.mimetype.startsWith('video/')) {
            cb(null, true);
        } else {
            cb(new Error('กรุณาอัพโหลดไฟล์วิดีโอเท่านั้น'));
        }
    },
   
});

// API สำหรับดึงรายการวิดีโอ
app.get('/api/videos', async (req, res) => {
    try {
        const videosDir = path.join(__dirname, 'public', 'videos');
        // สร้างโฟลเดอร์ถ้ายังไม่มี
        if (!fs.existsSync(videosDir)) {
            fs.mkdirSync(videosDir, { recursive: true });
        }
        
        const files = await readdir(videosDir);
        
        // กรองเฉพาะไฟล์วิดีโอ
        const videos = files.filter(file => 
            file.toLowerCase().endsWith('.mp4') || 
            file.toLowerCase().endsWith('.webm') || 
            file.toLowerCase().endsWith('.mov')
        );
        
        res.json({ success: true, videos: videos });
    } catch (error) {
        console.error('Error reading videos directory:', error);
        res.status(500).json({ 
            success: false, 
            error: 'ไม่สามารถอ่านรายการวิดีโอได้' 
        });
    }
});

// API สำหรับอัพโหลดวิดีโอ
app.post('/api/videos/upload', videoUpload.single('video'), (req, res) => {
    try {
        if (!req.file) {
            throw new Error('ไม่พบไฟล์วิดีโอ');
        }
        
        console.log('Uploaded file:', req.file);
        
        res.json({ 
            success: true, 
            message: 'อัพโหลดวิดีโอสำเร็จ',
            filename: req.file.filename,
            path: `/videos/${req.file.filename}`
        });
    } catch (error) {
        console.error('Error uploading video:', error);
        res.status(500).json({ 
            success: false, 
            error: error.message || 'ไม่สามารถอัพโหลดวิดีโอได้' 
        });
    }
});

// API สำหรับลบวิดีโอ
app.delete('/api/videos/:filename', async (req, res) => {
    try {
        const filename = req.params.filename;
        const filepath = path.join(__dirname, 'public', 'videos', filename);
        
        // ตรวจสอบว่าไฟล์มีอยู่จริง
        if (!fs.existsSync(filepath)) {
            throw new Error('ไม่พบไฟล์วิดีโอ');
        }
        
        // ลบไฟล์
        await fsPromises.unlink(filepath);
        
        res.json({ 
            success: true, 
            message: 'ลบวิดีโอสำเร็จ' 
        });
    } catch (error) {
        console.error('Error deleting video:', error);
        res.status(500).json({ 
            success: false, 
            error: error.message || 'ไม่สามารถลบวิดีโอได้' 
        });
    }
});

// เพิ่มฟังก์ชันค้นหา USB Relay
async function findUSBRelay(config = {
    vendorId: 0x16c0,
    productId: 0x05df,
    product: 'USBRelay2'
}, retries = 10, interval = 1000) {
    for (let i = 0; i < retries; i++) {
        const devices = HID.devices().filter(d => {
            const matchVendor = !config.vendorId || d.vendorId === config.vendorId;
            const matchProduct = !config.productId || d.productId === config.productId;
            const matchName = !config.product || d.product === config.product;
            return matchVendor && matchProduct && matchName;
        });

        if (devices.length > 0) {
            console.log(`พบ USB Relay แล้วหลังจากพยายาม ${i + 1} ครั้ง`);
            return devices[0];
        }

        console.log(`ไม่พบ USB Relay ครั้งที่ ${i + 1} กำลังลองใหม่...`);
        await new Promise(resolve => setTimeout(resolve, interval));
    }
    throw new Error(`ไม่พบ USB Relay หลังจากลองค้นหา ${retries} ครั้ง`);
}

// เก็บ device instance ไว้ใช้งาน
let relayDevice = null;

io.on('connection', async (socket) => {
    // ... โค้ดเดิม ...

    // เพิ่ม handler สำหรับควบคุม relay
    socket.on('controlRelay', async (data) => {
        try {
            if (!relayDevice) {
                const deviceConfig = {
                    vendorId: 0x16c0,
                    productId: 0x05df,
                    product: 'USBRelay2'
                };

                const deviceInfo = await findUSBRelay(deviceConfig);
                if (!deviceInfo) {
                    throw new Error('ไม่พบ USB Relay');
                }

                relayDevice = new HID.HID(deviceInfo.path);
                await new Promise(resolve => setTimeout(resolve, 100));
            }

            if (data.action === 'on') {
                relayDevice.sendFeatureReport([0, 0xFF, data.relay]);
                console.log(`เปิด relay ${data.relay}`);
            } else {
                relayDevice.sendFeatureReport([0, 0xFD, data.relay]);
                console.log(`ปิด relay ${data.relay}`);
            }

        } catch (err) {
            console.error('เกิดข้อผิดพลาดในการควบคุม relay:', err);
            relayDevice = null; // รีเซ็ต device instance เมื่อเกิดข้อผิดพลาด
            socket.emit('relayError', {
                message: 'เกิดข้อผิดพลาดในการควบคุม relay: ' + err.message
            });
        }
    });

    // เพิ่ม cleanup เมื่อ disconnect
    socket.on('disconnect', () => {
        if (relayDevice) {
            try {
                relayDevice.close();
                relayDevice = null;
            } catch (err) {
                console.error('Error closing relay device:', err);
            }
        }
    });

    // ... โค้ดเดิม ...
});

// เพิ่มที่ส่วนบนของไฟล์หลังจาก require ต่างๆ
const configPath = path.join(__dirname, 'config', 'config.json');

// เพิ่ม endpoint สำหรับตรวจสอบรหัสผ่าน
app.post('/verify-password', async (req, res) => {
    try {
        const { password } = req.body;
        const config = JSON.parse(await fsPromises.readFile(configPath, 'utf8'));

        if (password === config.password) {
            res.json({ success: true });
        } else {
            res.json({ success: false });
        }
    } catch (error) {
        console.error('Error verifying password:', error);
        res.status(500).json({ 
            success: false, 
            error: 'เกิดข้อผิดพลาดในการตรวจสอบรหัสผ่าน' 
        });
    }
});

// เพิ่ม middleware สำหรับป้องกันการเข้าถึงหน้า settings โดยตรง
app.get('/settings', async (req, res) => {
    res.render('settings');
});

