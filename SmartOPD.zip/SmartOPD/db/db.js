const mysql = require('mysql2');
const fs = require('fs');
const path = require('path');

// แก้ไขการอ่านไฟล์ config
const dbConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../config', 'dbConfig.json'), 'utf8'));

// สร้าง pool สำหรับฐานข้อมูลหลักเสมอ
const pools = {
    primary: mysql.createPool({
        host: dbConfig.host,
        user: dbConfig.user,
        password: dbConfig.password,
        database: dbConfig.primaryDatabase,
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0
    })
};

// สร้าง pool สำหรับฐานข้อมูลรองถ้าเปิดใช้งาน
if (dbConfig.useSecondaryDb && dbConfig.secondaryDatabase) {
    pools.secondary = mysql.createPool({
        host: dbConfig.host,
        user: dbConfig.user,
        password: dbConfig.password,
        database: dbConfig.secondaryDatabase,
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0
    });
}

// แปลง pool เป็น promise
const promisePools = {
    primary: pools.primary.promise()
};

if (pools.secondary) {
    promisePools.secondary = pools.secondary.promise();
}

module.exports = promisePools;